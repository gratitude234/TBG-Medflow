// src/utils/records.js
import { apiGet, apiPost } from "./apiClient";
import { getSessionUser } from "./session";

// -------------------------
// Date + time helpers
// -------------------------
export const parseYMDLocal = (ymd) => (ymd ? new Date(`${ymd}T00:00:00`) : null);

export const formatDisplayDate = (ymd) => {
  const d = parseYMDLocal(ymd);
  if (!d) return "—";

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const that = new Date(d.getFullYear(), d.getMonth(), d.getDate());

  const diffDays = Math.round((today - that) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays > 1 && diffDays <= 6) return `${diffDays} days ago`;

  try {
    return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });
  } catch {
    return ymd;
  }
};

export const formatTime12h = (t) => {
  if (!t) return "—";
  const s = String(t).trim();
  const m = s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (!m) return s;

  let hh = Number(m[1]);
  const mm = m[2];
  const ampm = hh >= 12 ? "PM" : "AM";
  hh = hh % 12;
  if (hh === 0) hh = 12;
  return `${hh}:${mm} ${ampm}`;
};

const toMinutes = (t) => {
  const s = String(t || "").trim();
  const m = s.match(/^(\d{1,2}):(\d{2})/);
  if (!m) return 0;
  const hh = Number(m[1]) || 0;
  const mm = Number(m[2]) || 0;
  return hh * 60 + mm;
};

const recordSortKey = (r) => {
  const date = String(r?.date || "");
  const timeMinutes = Number(r?.timeMinutes || 0);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return 0;
  const y = Number(date.slice(0, 4)) || 0;
  const m = Number(date.slice(5, 7)) || 0;
  const d = Number(date.slice(8, 10)) || 0;
  return y * 100000000 + m * 1000000 + d * 10000 + timeMinutes;
};

export const normalizeRecord = (r = {}) => {
  const id = r.id ?? r.record_id ?? r.recordId ?? null;

  const date = r.date ?? r.record_date ?? r.recordDate ?? "";
  const timeRaw = r.time ?? r.record_time ?? r.recordTime ?? "";
  const time = formatTime12h(timeRaw);
  const timeMinutes = toMinutes(timeRaw);

  const session = String(r.session ?? "").toLowerCase();

  const takenMedicationRaw = r.takenMedication ?? r.taken_medication ?? 0;
  const fastingRaw = r.fasting ?? 0;
  const shareRaw = r.shareWithClinician ?? r.share_with_clinician ?? 0;

  return {
    id,
    userId: Number(r.userId ?? r.user_id ?? 0) || null,

    date,
    displayDate: formatDisplayDate(date),
    time,
    timeMinutes,
    session,

    bpSystolic: r.bpSystolic ?? r.bp_systolic ?? null,
    bpDiastolic: r.bpDiastolic ?? r.bp_diastolic ?? null,
    heartRate: r.heartRate ?? r.heart_rate ?? null,
    temperature: r.temperature ?? null,
    bloodSugar: r.bloodSugar ?? r.blood_sugar ?? null,

    symptoms: r.symptoms ?? "",
    notes: r.notes ?? "",

    flags: {
      takenMedication: !!Number(takenMedicationRaw),
      fasting: !!Number(fastingRaw),
      shareWithClinician: !!Number(shareRaw),
    },
  };
};

// Backward-compatible helper (your views already import this)
export const getLoggedInUser = () => getSessionUser();

// -------------------------
// Fetch (POST with GET fallback) + sort newest-first
// NOW supports Option A: patientUserId + viewerUserId for access-controlled reads.
// -------------------------
export const fetchUserRecords = async (patientUserId, viewerUserId = null) => {
  let data;

  const pid = Number(patientUserId) || 0;
  const vid = viewerUserId != null ? Number(viewerUserId) || 0 : 0;

  const postBody = {
    // keep old keys
    userId: pid,
    user_id: pid,
    // new (optional) keys for access enforcement
    patientUserId: pid,
    patient_user_id: pid,
    viewerUserId: vid || undefined,
    viewer_user_id: vid || undefined,
  };

  try {
    data = await apiPost("list_records.php", postBody);
  } catch (e) {
    const msg = String(e?.message || "").toLowerCase();
    if (msg.includes("method not allowed") || msg.includes("405")) {
      const qs = new URLSearchParams();
      qs.set("user_id", String(pid));
      if (vid) qs.set("viewer_user_id", String(vid));
      data = await apiGet(`list_records.php?${qs.toString()}`);
    } else {
      throw e;
    }
  }

  const raw = Array.isArray(data?.records) ? data.records : [];

  const normalized = raw.map(normalizeRecord).filter((x) => x?.id != null && x?.date);

  normalized.sort((a, b) => recordSortKey(b) - recordSortKey(a));
  return normalized;
};
