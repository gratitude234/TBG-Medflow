// src/utils/monitoring.js
import { apiGet, apiPost } from "./apiClient";

/**
 * Option A: Share code → access grant → clinician/student monitors patients
 *
 * Expected backend endpoints:
 * - create_share_invite.php (POST)  { patientUserId, allowedRole? } -> { success, code, expiresAt }
 * - accept_share_invite.php (POST)  { viewerUserId, code } -> { success, patient: {...}, grant: {...} }
 * - list_monitoring_patients.php (GET/POST) viewerUserId -> { success, patients: [...] }
 * - revoke_access.php (POST) { patientUserId, viewerUserId? grantId? code? } -> { success }
 */

const ACTIVE_PATIENT_KEY = (viewerId) => `medflowActivePatient:${viewerId}`;

export function setActivePatientForViewer(viewerId, patient) {
  try {
    if (!viewerId) return;
    if (!patient) {
      localStorage.removeItem(ACTIVE_PATIENT_KEY(viewerId));
      return;
    }
    localStorage.setItem(ACTIVE_PATIENT_KEY(viewerId), JSON.stringify(patient));
  } catch {
    // ignore
  }
}

export function getActivePatientForViewer(viewerId) {
  try {
    if (!viewerId) return null;
    const raw = localStorage.getItem(ACTIVE_PATIENT_KEY(viewerId));
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export async function createShareInvite(payload) {
  const data = await apiPost("create_share_invite.php", payload);
  if (!data?.success) throw new Error(data?.error || "Failed to create share invite");
  return data;
}

export async function acceptShareInvite(payload) {
  const data = await apiPost("accept_share_invite.php", payload);
  if (!data?.success) throw new Error(data?.error || "Failed to accept share code");
  return data;
}

export async function listMonitoringPatients(viewerUserId) {
  let data;
  try {
    data = await apiGet(`list_monitoring_patients.php?viewerUserId=${encodeURIComponent(viewerUserId)}`);
  } catch (e) {
    // fallback to POST if needed
    data = await apiPost("list_monitoring_patients.php", { viewerUserId });
  }
  if (!data?.success) throw new Error(data?.error || "Failed to load monitoring patients");
  return Array.isArray(data?.patients) ? data.patients : [];
}

export async function revokeAccess(payload) {
  const data = await apiPost("revoke_access.php", payload);
  if (!data?.success) throw new Error(data?.error || "Failed to revoke access");
  return data;
}
