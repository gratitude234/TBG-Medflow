<!-- src/views/RecordsView.vue -->
<template>
  <main class="mx-auto max-w-6xl px-4 pb-10 pt-4 space-y-6 sm:space-y-8 sm:pt-6 lg:pt-8">
    <!-- Toast -->
    <div
      v-if="toast.visible"
      class="rounded-2xl px-3 py-2 text-[11px] shadow-sm ring-1"
      :class="{
        'bg-sky-50 text-sky-800 ring-sky-100': toast.type === 'info',
        'bg-emerald-50 text-emerald-700 ring-emerald-100': toast.type === 'success',
        'bg-rose-50 text-rose-700 ring-rose-100': toast.type === 'error',
      }"
    >
      {{ toast.message }}
    </div>

    <!-- Page header -->
    <header class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <!-- Left -->
      <div>
        <RouterLink
          :to="{ name: 'dashboard' }"
          class="inline-flex items-center gap-2 rounded-full bg-white/70 px-3 py-1.5 text-[11px] font-medium text-slate-600 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50 hover:text-slate-900"
        >
          <span class="text-sm">←</span>
          <span>Back to dashboard</span>
        </RouterLink>

        <div class="mt-3 space-y-1">
          <div class="flex flex-wrap items-center gap-2">
            <h1 class="text-2xl font-semibold text-slate-900 sm:text-2xl">{{ pageTitle }}</h1>

            <span
              class="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-1 text-[11px] font-medium text-sky-700 ring-1 ring-sky-100"
            >
              📋 Vitals
            </span>

            <span
              v-if="roleKey"
              class="inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-semibold ring-1"
              :class="roleBadgeClass"
              title="Your role is stored on your account"
            >
              <span class="h-1.5 w-1.5 rounded-full" :class="roleDotClass" />
              {{ roleLabelText }}
            </span>

            <span
              v-if="isViewerMode"
              class="inline-flex items-center gap-2 rounded-full bg-slate-50 px-3 py-1 text-[11px] font-semibold text-slate-700 ring-1 ring-slate-200"
              title="You’re viewing a patient workspace"
            >
              👀 Viewing patient
            </span>
          </div>

          <p class="text-sm text-slate-600">
            {{ headerSubtitle }}
          </p>

          <div v-if="isViewerMode" class="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
            <span>
              Patient:
              <span class="font-semibold text-slate-700">{{ patientLabel }}</span>
            </span>

            <RouterLink
              to="/share"
              class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50"
              title="Pick a different patient"
            >
              Change patient
            </RouterLink>
          </div>

          <div
            v-if="needsPatientPick"
            class="mt-3 rounded-2xl bg-amber-50 p-4 text-[11px] text-amber-900"
          >
            You’re signed in as a clinician/student. Pick a patient first:
            <div class="mt-3">
              <RouterLink
                to="/share"
                class="inline-flex rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
              >
                Open Share & Monitoring
              </RouterLink>
            </div>
          </div>
        </div>
      </div>

      <!-- Right -->
      <div class="flex flex-col items-start gap-2 text-left sm:items-end sm:text-right">
        <p class="text-[11px] text-slate-400">
          Total records:
          <span class="font-medium text-slate-600">{{ isLoading ? "…" : totalCount }}</span>
        </p>

        <RouterLink
          v-if="!needsPatientPick"
          :to="addLink"
          class="inline-flex items-center justify-center gap-2 rounded-full bg-sky-600 px-4 py-2 text-xs font-semibold text-white shadow-md shadow-sky-500/25 transition hover:bg-sky-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-50"
        >
          <span class="flex h-4 w-4 items-center justify-center rounded-full bg-sky-500 text-[11px]">＋</span>
          <span>{{ addButtonLabel }}</span>
        </RouterLink>
      </div>
    </header>

    <!-- Main content -->
    <section v-if="!needsPatientPick" class="grid gap-6 lg:grid-cols-[minmax(0,2.1fr)_minmax(0,1.3fr)]">
      <!-- Left -->
      <article class="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-100 sm:p-5">
        <div class="flex items-start justify-between gap-3">
          <div>
            <h2 class="text-sm font-semibold text-slate-900">Vitals records</h2>
            <p class="mt-1 text-xs text-slate-500">Tap a row to see full details on the right.</p>
          </div>

          <div class="flex items-center gap-2">
            <button
              type="button"
              class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-medium text-slate-700 shadow-sm transition hover:border-sky-500 hover:text-sky-700 disabled:opacity-60"
              @click="fetchRecords"
              :disabled="isLoading"
              title="Refresh"
            >
              🔄 <span>Refresh</span>
            </button>
          </div>
        </div>

        <!-- Error -->
        <div
          v-if="loadError"
          class="mt-6 space-y-3 rounded-2xl bg-rose-50 px-4 py-6 text-center text-xs text-rose-700 ring-1 ring-rose-100"
        >
          <p class="font-semibold">Couldn’t load records.</p>
          <p class="text-[11px] opacity-90">{{ loadError }}</p>
          <div class="flex justify-center gap-2">
            <button
              type="button"
              class="inline-flex items-center justify-center rounded-full bg-rose-700 px-4 py-2 text-[11px] font-semibold text-white hover:bg-rose-800"
              @click="fetchRecords"
            >
              Retry
            </button>
          </div>
        </div>

        <!-- Empty -->
        <div
          v-else-if="!isLoading && !totalCount"
          class="mt-6 space-y-3 rounded-2xl bg-slate-50 px-4 py-6 text-center text-xs text-slate-600"
        >
          <p class="font-semibold text-slate-900">{{ emptyState.title }}</p>
          <p class="text-[11px] text-slate-600">{{ emptyState.body }}</p>

          <div class="mt-3 flex flex-wrap justify-center gap-2">
            <RouterLink
              :to="addLink"
              class="inline-flex items-center justify-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-[11px] font-semibold text-white shadow-sm hover:bg-slate-800"
            >
              <span>＋</span>
              <span>{{ emptyState.primaryCta }}</span>
            </RouterLink>

            <RouterLink
              v-if="isViewerMode"
              to="/share"
              class="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-semibold text-slate-700 hover:bg-slate-100"
            >
              Change patient
            </RouterLink>
          </div>
        </div>

        <!-- Records list -->
        <div v-else class="mt-4">
          <button
            v-for="record in filteredRecords"
            :key="record.id"
            type="button"
            @click="selectedId = record.id"
            :class="[
              'mt-1 w-full rounded-2xl px-3 py-2 text-left text-xs transition',
              selectedId === record.id ? 'bg-sky-50 ring-1 ring-sky-100 shadow-sm' : 'hover:bg-slate-50',
            ]"
          >
            <p class="text-xs font-medium text-slate-800">
              {{ record.displayDate }} · {{ record.time }}
            </p>
            <p class="mt-0.5 text-[11px] text-slate-600">
              {{ prettySession(record.session) }} • {{ record.date }}
            </p>

            <p class="mt-1 text-[11px] text-slate-700">
              <span v-if="record.bpSystolic && record.bpDiastolic">
                BP {{ record.bpSystolic }}/{{ record.bpDiastolic }} mmHg
              </span>
              <span v-if="record.heartRate"> · HR {{ record.heartRate }} bpm</span>
              <span v-if="record.temperature != null"> · Temp {{ record.temperature }} °C</span>
              <span v-if="record.bloodSugar"> · Sugar {{ record.bloodSugar }} mg/dL</span>
            </p>

            <p class="mt-1 line-clamp-2 text-[11px] text-slate-600">
              {{ previewText(record.symptoms || record.notes) }}
            </p>
          </button>
        </div>
      </article>

      <!-- Right detail -->
      <aside class="space-y-4">
        <article class="min-h-[220px] rounded-2xl bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-4 shadow-sm ring-1 ring-sky-100 sm:p-5">
          <div v-if="isLoading" class="text-[11px] text-slate-500">Loading…</div>

          <div v-else-if="!selectedRecord" class="flex h-full items-center">
            <p class="text-xs text-slate-500">Select a record on the left to see full details here.</p>
          </div>

          <div v-else class="space-y-3 text-[11px] text-slate-700">
            <div>
              <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500">Record detail</p>
              <h2 class="mt-1 text-lg font-semibold text-slate-900">
                {{ selectedRecord.displayDate }} · {{ selectedRecord.time }}
              </h2>
              <p class="mt-1 text-[11px] text-slate-500">
                Session: {{ prettySession(selectedRecord.session) }} • {{ selectedRecord.date }}
              </p>
            </div>

            <div class="rounded-xl bg-white/80 p-3 ring-1 ring-slate-100">
              <p class="text-[10px] font-medium text-slate-500">Vitals</p>
              <p class="mt-1 text-[11px] text-slate-700">
                <span v-if="selectedRecord.bpSystolic && selectedRecord.bpDiastolic">
                  BP {{ selectedRecord.bpSystolic }}/{{ selectedRecord.bpDiastolic }} mmHg
                </span>
                <span v-if="selectedRecord.heartRate"> · HR {{ selectedRecord.heartRate }} bpm</span>
                <span v-if="selectedRecord.temperature != null"> · Temp {{ selectedRecord.temperature }} °C</span>
                <span v-if="selectedRecord.bloodSugar"> · Sugar {{ selectedRecord.bloodSugar }} mg/dL</span>
              </p>
            </div>

            <div class="space-y-2">
              <div>
                <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500">Symptoms</p>
                <p class="mt-1 text-[11px] text-slate-700">
                  {{ selectedRecord.symptoms ? selectedRecord.symptoms : "No symptoms recorded." }}
                </p>
              </div>
              <div>
                <p class="text-[10px] font-medium uppercase tracking-wide text-slate-500">Notes</p>
                <p class="mt-1 text-[11px] text-slate-700">
                  {{ selectedRecord.notes ? selectedRecord.notes : "No additional notes." }}
                </p>
              </div>
            </div>

            <p class="pt-1 text-[10px] text-slate-400">For record-keeping only · Not medical advice.</p>
          </div>
        </article>
      </aside>
    </section>
  </main>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from "vue";
import { RouterLink, useRoute, useRouter } from "vue-router";
import { fetchUserRecords, getLoggedInUser } from "../utils/records";
import { normalizeRole, roleLabel as roleLabelFn } from "../utils/profile";
import { getActivePatientForViewer } from "../utils/monitoring";

const router = useRouter();
const route = useRoute();

const toast = reactive({ visible: false, type: "info", message: "", _t: null });
const showToast = (message, type = "info", ms = 2600) => {
  toast.type = type;
  toast.message = message;
  toast.visible = true;
  if (toast._t) clearTimeout(toast._t);
  toast._t = setTimeout(() => (toast.visible = false), ms);
};

const sessionUser = ref(null);

const records = ref([]);
const isLoading = ref(false);
const loadError = ref("");

const selectedId = ref(null);

const roleKey = computed(() => normalizeRole(sessionUser.value?.role || "patient"));
const roleLabelText = computed(() => roleLabelFn(roleKey.value));

const isViewerMode = computed(() => roleKey.value === "clinician" || roleKey.value === "student");
const queryPatientId = computed(() => Number(route.query.patientUserId || 0) || 0);

const activePatient = computed(() => {
  if (!sessionUser.value?.id) return null;
  return getActivePatientForViewer(sessionUser.value.id);
});

const patientContextId = computed(() => {
  if (!sessionUser.value?.id) return 0;
  if (!isViewerMode.value) return sessionUser.value.id;
  return queryPatientId.value || Number(activePatient.value?.id || 0) || 0;
});

const needsPatientPick = computed(() => isViewerMode.value && !patientContextId.value);

const patientLabel = computed(() => {
  if (!isViewerMode.value) return sessionUser.value?.fullName || "—";
  const p = activePatient.value;
  if (queryPatientId.value && p?.id === queryPatientId.value) return p.fullName || `Patient #${p.id}`;
  if (queryPatientId.value) return `Patient #${queryPatientId.value}`;
  if (p?.id) return p.fullName || `Patient #${p.id}`;
  return "—";
});

const pageTitle = computed(() => (isViewerMode.value ? "Patient Records" : "My Records"));

const roleBadgeClass = computed(() => {
  const r = roleKey.value;
  if (r === "student") return "bg-emerald-50 text-emerald-800 ring-emerald-100";
  if (r === "clinician") return "bg-indigo-50 text-indigo-800 ring-indigo-100";
  if (r === "other") return "bg-amber-50 text-amber-900 ring-amber-100";
  return "bg-sky-50 text-sky-800 ring-sky-100";
});
const roleDotClass = computed(() => {
  const r = roleKey.value;
  if (r === "student") return "bg-emerald-500";
  if (r === "clinician") return "bg-indigo-500";
  if (r === "other") return "bg-amber-500";
  return "bg-sky-500";
});

const headerSubtitle = computed(() => {
  if (needsPatientPick.value) return "Pick a patient to review their vitals.";
  if (isViewerMode.value) return "Review vitals for the selected patient workspace.";
  return "Browse and review your previous vitals in one place.";
});

const addButtonLabel = computed(() => (isViewerMode.value ? "Log vitals" : "Add vitals"));

const addLink = computed(() => {
  // When in viewer mode, preserve patient context
  if (!isViewerMode.value) return { name: "add" };
  const pid = patientContextId.value;
  return { name: "add", query: pid ? { patientUserId: String(pid) } : {} };
});

const emptyState = computed(() => {
  if (isViewerMode.value) {
    return {
      title: "No vitals yet for this patient.",
      body: "If this is unexpected, confirm the patient shared the correct code or try refreshing.",
      primaryCta: "Log first vitals",
    };
  }
  return {
    title: "No vitals records yet.",
    body: "Start by adding your first reading. You can log BP, temperature, heart rate, and notes.",
    primaryCta: "Add your first vitals",
  };
});

const totalCount = computed(() => records.value.length);

const prettySession = (session) => {
  const s = String(session || "").trim().toLowerCase();
  if (!s) return "Unknown";
  if (s === "morning") return "Morning";
  if (s === "afternoon") return "Afternoon";
  if (s === "evening") return "Evening";
  if (s === "night") return "Night";
  return String(session);
};

const previewText = (value) => {
  if (!value) return "No notes or symptoms.";
  const trimmed = String(value).trim();
  return trimmed.length <= 80 ? trimmed : trimmed.slice(0, 77) + "…";
};

const fetchRecords = async () => {
  loadError.value = "";
  isLoading.value = true;

  try {
    const user = getLoggedInUser();
    sessionUser.value = user || null;

    if (!user?.id) {
      loadError.value = "You’re not logged in. Please log in again.";
      showToast(loadError.value, "error");
      router.push({ name: "login", query: { redirect: "/records" } });
      return;
    }

    if (needsPatientPick.value) {
      records.value = [];
      selectedId.value = null;
      return;
    }

    const pid = patientContextId.value;
    const vid = isViewerMode.value ? user.id : null;

    const list = await fetchUserRecords(pid, vid);
    records.value = Array.isArray(list) ? list : [];

    if (!records.value.length) selectedId.value = null;
    else if (!selectedId.value) selectedId.value = records.value[0].id;
    else if (!records.value.some((r) => r.id === selectedId.value)) selectedId.value = records.value[0].id;
  } catch (err) {
    const msg = err?.message || "Failed to load records. Check your API and try again.";
    loadError.value = msg;
    showToast(msg, "error", 4200);
  } finally {
    isLoading.value = false;
  }
};

const filteredRecords = computed(() => {
  // keep newest-first already sorted by util, but preserve stable rendering:
  return [...records.value];
});

const selectedRecord = computed(() => {
  if (!selectedId.value) return null;
  return records.value.find((r) => r.id === selectedId.value) || null;
});

watch(
  () => route.query.patientUserId,
  () => {
    // patient context changed → reload
    if (isViewerMode.value) fetchRecords();
  }
);

onMounted(fetchRecords);
</script>
