<!-- src/views/EncountersView.vue -->
<template>
  <main class="mx-auto max-w-6xl px-4 pb-10 pt-4 space-y-6">
    <header class="flex items-start justify-between gap-3">
      <div>
        <h1 class="text-lg font-bold text-slate-900">{{ title }}</h1>
        <p class="mt-1 text-[11px] text-slate-600">{{ subtitle }}</p>

        <div v-if="needsPatientPick" class="mt-3 rounded-2xl bg-amber-50 p-4 text-[11px] text-amber-900">
          Pick a patient first to view encounters.
          <div class="mt-3">
            <RouterLink
              to="/share"
              class="inline-flex rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
            >
              Open Share & Monitoring
            </RouterLink>
          </div>
        </div>
      </div>

      <RouterLink
        v-if="!needsPatientPick"
        :to="newEncounterLink"
        class="inline-flex rounded-full bg-sky-600 px-4 py-2 text-xs font-semibold text-white hover:bg-sky-700"
      >
        ＋ New Encounter
      </RouterLink>
    </header>

    <section v-if="!needsPatientPick" class="rounded-2xl border border-slate-200 bg-white p-4">
      <div v-if="loading" class="text-[11px] text-slate-500">Loading…</div>

      <div v-else-if="error" class="rounded-2xl bg-rose-50 p-4 text-[11px] text-rose-700">
        {{ error }}
      </div>

      <div v-else-if="!encounters.length" class="rounded-2xl bg-slate-50 p-4 text-[11px] text-slate-600">
        No encounters yet.
      </div>

      <div v-else class="space-y-2">
        <div
          v-for="e in encounters"
          :key="e.id"
          class="rounded-2xl border border-slate-100 bg-white p-4"
        >
          <p class="text-[11px] font-semibold text-slate-900">
            {{ e.displayDate }} · {{ e.time }}
            <span class="ml-2 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] text-slate-600">{{ e.status }}</span>
          </p>
          <p class="mt-1 text-[11px] text-slate-600">{{ e.chiefComplaint }}</p>
          <p class="mt-1 text-[10px] text-slate-400">
            Author: {{ e.authorRole }} {{ e.authorUserId ? `(#${e.authorUserId})` : "" }}
          </p>
        </div>
      </div>
    </section>
  </main>
</template>

<script setup>
import { computed, onMounted, ref, watch } from "vue";
import { RouterLink, useRoute, useRouter } from "vue-router";
import { getSessionUser } from "../utils/session";
import { normalizeRole } from "../utils/profile";
import { fetchUserEncounters } from "../utils/encounters";
import { getActivePatientForViewer } from "../utils/monitoring";

const route = useRoute();
const router = useRouter();

const user = ref(null);
const encounters = ref([]);
const loading = ref(false);
const error = ref("");

const roleKey = computed(() => normalizeRole(user.value?.role || "patient"));
const isViewerMode = computed(() => roleKey.value === "clinician" || roleKey.value === "student");

const queryPatientId = computed(() => Number(route.query.patientUserId || 0) || 0);

const activePatient = computed(() => {
  if (!user.value?.id) return null;
  return getActivePatientForViewer(user.value.id);
});

const patientContextId = computed(() => {
  if (!user.value?.id) return 0;
  if (!isViewerMode.value) return user.value.id;
  return queryPatientId.value || Number(activePatient.value?.id || 0) || 0;
});

const needsPatientPick = computed(() => isViewerMode.value && !patientContextId.value);

const title = computed(() => (isViewerMode.value ? "Patient Encounters" : "My Encounters"));
const subtitle = computed(() => {
  if (needsPatientPick.value) return "Select a patient to view encounter notes.";
  if (isViewerMode.value) return "Encounter notes for the selected patient workspace.";
  return "Your encounter documentation.";
});

const newEncounterLink = computed(() => {
  if (!isViewerMode.value) return { name: "add-encounter" };
  const pid = patientContextId.value;
  return { name: "add-encounter", query: pid ? { patientUserId: String(pid) } : {} };
});

const load = async () => {
  error.value = "";
  loading.value = true;

  try {
    user.value = getSessionUser();

    if (!user.value?.id) {
      router.push({ name: "login", query: { redirect: "/encounters" } });
      return;
    }

    if (needsPatientPick.value) {
      encounters.value = [];
      return;
    }

    const pid = patientContextId.value;
    const vid = isViewerMode.value ? user.value.id : null;

    const list = await fetchUserEncounters(pid, vid);
    encounters.value = Array.isArray(list) ? list : [];
  } catch (e) {
    error.value = e?.message || "Failed to load encounters.";
  } finally {
    loading.value = false;
  }
};

watch(
  () => route.query.patientUserId,
  () => {
    if (isViewerMode.value) load();
  }
);

onMounted(load);
</script>
