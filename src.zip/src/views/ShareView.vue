<!-- src/views/ShareView.vue -->
<template>
  <main class="mx-auto max-w-6xl px-4 pb-10 pt-4 space-y-6">
    <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div class="flex items-start justify-between gap-3">
        <div>
          <h1 class="text-lg font-bold text-slate-900">Sharing & Monitoring</h1>
          <p class="mt-1 text-[11px] text-slate-600">
            Patients share a code. Clinicians/Students enter the code to monitor that patient’s records.
          </p>
        </div>

        <RouterLink
          to="/dashboard"
          class="hidden sm:inline-flex rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          Back to Dashboard
        </RouterLink>
      </div>

      <!-- Not logged in -->
      <div v-if="!user" class="mt-4 rounded-2xl bg-amber-50 p-4 text-[11px] text-amber-900">
        You’re not logged in. Log in to create or accept monitoring codes.
        <div class="mt-3">
          <RouterLink
            to="/login"
            class="inline-flex rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
          >
            Log in
          </RouterLink>
        </div>
      </div>

      <div v-else class="mt-5 space-y-6">
        <!-- Role pill -->
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-[11px] text-slate-500">Signed in as</span>
          <span class="inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-semibold ring-1" :class="roleBadgeClass">
            <span class="h-1.5 w-1.5 rounded-full" :class="roleDotClass" />
            {{ roleLabelText }}
          </span>
        </div>

        <!-- PATIENT MODE -->
        <div v-if="isPatient" class="rounded-2xl border border-slate-200 p-4">
          <h2 class="text-sm font-semibold text-slate-900">Share a monitoring code</h2>
          <p class="mt-1 text-[11px] text-slate-600">
            Give this code to your clinician or student nurse. They will enter it to access your records.
          </p>

          <div class="mt-4 flex flex-wrap items-center gap-2">
            <div class="relative">
              <select
                v-model="allowedRole"
                class="appearance-none rounded-full border border-slate-200 bg-slate-50 px-3 pr-7 py-2 text-[11px] text-slate-700 outline-none transition focus:border-sky-400 focus:bg-white focus:ring-2 focus:ring-sky-100"
              >
                <option value="clinician">Allow Clinician/Mentor</option>
                <option value="student">Allow Student Nurse</option>
              </select>
              <span class="pointer-events-none absolute inset-y-0 right-2 flex items-center text-[9px] text-slate-400">▾</span>
            </div>

            <button
              type="button"
              class="inline-flex items-center gap-2 rounded-full bg-sky-600 px-4 py-2 text-xs font-semibold text-white shadow-sm shadow-sky-500/25 hover:bg-sky-700 disabled:opacity-60"
              :disabled="busy"
              @click="onCreateInvite"
            >
              🔐 Generate code
            </button>

            <button
              v-if="invite.code"
              type="button"
              class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              @click="copy(invite.code)"
            >
              📋 Copy code
            </button>
          </div>

          <div v-if="invite.code" class="mt-4 rounded-2xl bg-slate-50 p-4">
            <p class="text-[11px] text-slate-600">Your monitoring code:</p>
            <p class="mt-1 text-lg font-extrabold tracking-widest text-slate-900">{{ invite.code }}</p>
            <p v-if="invite.expiresAt" class="mt-1 text-[11px] text-slate-500">
              Expires: <span class="font-medium text-slate-700">{{ invite.expiresAt }}</span>
            </p>

            <div class="mt-3 rounded-xl bg-white p-3 ring-1 ring-slate-100">
              <p class="text-[11px] font-semibold text-slate-900">Message to send</p>
              <p class="mt-1 whitespace-pre-wrap text-[11px] text-slate-700">{{ inviteMessage }}</p>
              <div class="mt-2 flex flex-wrap gap-2">
                <button
                  type="button"
                  class="inline-flex items-center gap-2 rounded-full bg-slate-900 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-slate-800"
                  @click="copy(inviteMessage)"
                >
                  📋 Copy message
                </button>
              </div>
            </div>
          </div>

          <div class="mt-4 rounded-2xl bg-amber-50 p-4 text-[11px] text-amber-900">
            Safety: only share codes with people you trust. You can revoke access anytime (backend endpoint: revoke_access.php).
          </div>

          <!-- (Optional) revoke by code (simple MVP) -->
          <div class="mt-4 rounded-2xl border border-slate-200 p-4">
            <p class="text-[11px] font-semibold text-slate-900">Revoke access (MVP)</p>
            <p class="mt-1 text-[11px] text-slate-600">Paste the code to revoke the access grant created by it.</p>

            <div class="mt-3 flex flex-wrap items-center gap-2">
              <input
                v-model="revokeCode"
                type="text"
                placeholder="Enter code"
                class="w-56 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] text-slate-900 placeholder:text-slate-400 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-100"
              />
              <button
                type="button"
                class="inline-flex items-center gap-2 rounded-full bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-700 disabled:opacity-60"
                :disabled="busy || !revokeCode.trim()"
                @click="onRevokeByCode"
              >
                🛑 Revoke
              </button>
            </div>
          </div>
        </div>

        <!-- CLINICIAN/STUDENT MODE -->
        <div v-else class="space-y-5">
          <div class="rounded-2xl border border-slate-200 p-4">
            <h2 class="text-sm font-semibold text-slate-900">Enter a patient share code</h2>
            <p class="mt-1 text-[11px] text-slate-600">
              Ask the patient for their monitoring code, then enter it here to connect.
            </p>

            <div class="mt-4 flex flex-wrap items-center gap-2">
              <input
                v-model="codeInput"
                type="text"
                placeholder="e.g., A1B2C3"
                class="w-56 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-semibold tracking-widest text-slate-900 placeholder:tracking-normal placeholder:font-normal placeholder:text-slate-400 focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-100"
              />
              <button
                type="button"
                class="inline-flex items-center gap-2 rounded-full bg-sky-600 px-4 py-2 text-xs font-semibold text-white shadow-sm shadow-sky-500/25 hover:bg-sky-700 disabled:opacity-60"
                :disabled="busy || !codeInput.trim()"
                @click="onAcceptCode"
              >
                🔗 Connect
              </button>
            </div>

            <div v-if="acceptedPatient" class="mt-4 rounded-2xl bg-emerald-50 p-4 text-[11px] text-emerald-900 ring-1 ring-emerald-100">
              Connected to <span class="font-semibold">{{ acceptedPatient.fullName || ("Patient #" + acceptedPatient.id) }}</span>.
              <div class="mt-3 flex flex-wrap gap-2">
                <RouterLink
                  :to="patientRecordsLink(acceptedPatient.id)"
                  class="inline-flex items-center justify-center rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                >
                  Open Records
                </RouterLink>
                <RouterLink
                  :to="patientEncountersLink(acceptedPatient.id)"
                  class="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Open Encounters
                </RouterLink>
              </div>
            </div>
          </div>

          <div class="rounded-2xl border border-slate-200 p-4">
            <div class="flex items-start justify-between gap-3">
              <div>
                <h2 class="text-sm font-semibold text-slate-900">My monitoring patients</h2>
                <p class="mt-1 text-[11px] text-slate-600">
                  Patients who shared access with you.
                </p>
              </div>

              <button
                type="button"
                class="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-60"
                :disabled="busy"
                @click="loadPatients"
              >
                🔄 Refresh
              </button>
            </div>

            <div v-if="patientsLoading" class="mt-4 text-[11px] text-slate-500">
              Loading…
            </div>

            <div v-else-if="!patients.length" class="mt-4 rounded-2xl bg-slate-50 p-4 text-[11px] text-slate-600">
              No patients yet. Ask a patient for a share code and connect.
            </div>

            <div v-else class="mt-4 grid gap-2 sm:grid-cols-2">
              <button
                v-for="p in patients"
                :key="p.patientUserId || p.id"
                type="button"
                class="rounded-2xl border border-slate-200 bg-white p-4 text-left hover:bg-slate-50"
                @click="openPatient(p)"
              >
                <p class="text-[11px] font-semibold text-slate-900">
                  {{ p.fullName || p.patientName || ("Patient #" + (p.patientUserId || p.id)) }}
                </p>
                <p class="mt-1 text-[11px] text-slate-600">
                  Last record: <span class="font-medium text-slate-700">{{ p.lastRecordAt || p.last_record_at || "—" }}</span>
                </p>
                <p class="mt-1 text-[11px] text-slate-600">
                  Last encounter: <span class="font-medium text-slate-700">{{ p.lastEncounterAt || p.last_encounter_at || "—" }}</span>
                </p>
                <p class="mt-2 text-[11px] font-medium text-sky-700">Open →</p>
              </button>
            </div>
          </div>
        </div>

        <!-- Toast -->
        <div v-if="toast.visible" class="rounded-2xl px-3 py-2 text-[11px] shadow-sm ring-1"
          :class="{
            'bg-sky-50 text-sky-800 ring-sky-100': toast.type === 'info',
            'bg-emerald-50 text-emerald-700 ring-emerald-100': toast.type === 'success',
            'bg-rose-50 text-rose-700 ring-rose-100': toast.type === 'error',
          }"
        >
          {{ toast.message }}
        </div>
      </div>
    </section>
  </main>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from "vue";
import { RouterLink, useRouter } from "vue-router";
import { getSessionUser } from "../utils/session";
import { normalizeRole, roleLabel as roleLabelFn } from "../utils/profile";
import {
  acceptShareInvite,
  createShareInvite,
  listMonitoringPatients,
  revokeAccess,
  setActivePatientForViewer,
} from "../utils/monitoring";

const router = useRouter();

const user = ref(null);
const busy = ref(false);

const toast = reactive({ visible: false, type: "info", message: "", _t: null });
const showToast = (message, type = "info", ms = 2600) => {
  toast.type = type;
  toast.message = message;
  toast.visible = true;
  if (toast._t) clearTimeout(toast._t);
  toast._t = setTimeout(() => (toast.visible = false), ms);
};

const roleKey = computed(() => normalizeRole(user.value?.role || "patient"));
const roleLabelText = computed(() => roleLabelFn(roleKey.value));
const isPatient = computed(() => roleKey.value === "patient");

const roleBadgeClass = computed(() => {
  const r = roleKey.value;
  if (r === "student") return "bg-emerald-50 text-emerald-800 ring-emerald-100";
  if (r === "clinician") return "bg-indigo-50 text-indigo-800 ring-indigo-100";
  if (r === "other") return "bg-amber-50 text-amber-900 ring-amber-100";
  return "bg-sky-50 text-sky-800 ring-sky-100";
});
const roleDotClass = computed(() => {
  const r = roleKey.value;
  if (r === "student") return "bg-emerald-500";
  if (r === "clinician") return "bg-indigo-500";
  if (r === "other") return "bg-amber-500";
  return "bg-sky-500";
});

// Patient invite generation
const allowedRole = ref("clinician");
const invite = reactive({ code: "", expiresAt: "" });
const revokeCode = ref("");

// Clinician/student accept
const codeInput = ref("");
const acceptedPatient = ref(null);

// Monitoring list
const patientsLoading = ref(false);
const patients = ref([]);

const inviteMessage = computed(() => {
  const name = user.value?.fullName || "Patient";
  return `Hello, this is my TBG Medflow monitoring code.

Patient: ${name}
Code: ${invite.code || "—"}

Please open Medflow → Share & Monitoring → Enter Code to connect.`;
});

const copy = async (text) => {
  try {
    await navigator.clipboard.writeText(String(text || ""));
    showToast("Copied.", "success", 1600);
  } catch {
    showToast("Could not copy. Please copy manually.", "error", 2600);
  }
};

const onCreateInvite = async () => {
  if (!user.value?.id) return;

  busy.value = true;
  try {
    const data = await createShareInvite({
      patientUserId: user.value.id,
      allowedRole: allowedRole.value,
    });

    invite.code = String(data?.code || "");
    invite.expiresAt = String(data?.expiresAt || "");

    showToast("Monitoring code created.", "success");
  } catch (e) {
    showToast(e?.message || "Failed to create code", "error", 3200);
  } finally {
    busy.value = false;
  }
};

const onAcceptCode = async () => {
  if (!user.value?.id) return;

  busy.value = true;
  try {
    const data = await acceptShareInvite({
      viewerUserId: user.value.id,
      code: codeInput.value.trim(),
    });

    const p = data?.patient || data?.patientUser || null;
    acceptedPatient.value = p;

    // store active patient context for this viewer
    if (p?.id) {
      setActivePatientForViewer(user.value.id, { id: p.id, fullName: p.fullName || p.full_name || "" });
      await loadPatients();
    }

    showToast("Connected successfully.", "success");
    codeInput.value = "";
  } catch (e) {
    showToast(e?.message || "Failed to connect", "error", 3600);
  } finally {
    busy.value = false;
  }
};

const loadPatients = async () => {
  if (!user.value?.id) return;

  patientsLoading.value = true;
  try {
    const list = await listMonitoringPatients(user.value.id);

    // normalize shape
    patients.value = list.map((x) => ({
      id: x.patientUserId || x.patient_user_id || x.id,
      patientUserId: x.patientUserId || x.patient_user_id || x.id,
      fullName: x.fullName || x.patientName || x.full_name || x.name || "",
      lastRecordAt: x.lastRecordAt || x.last_record_at || "",
      lastEncounterAt: x.lastEncounterAt || x.last_encounter_at || "",
    }));
  } catch (e) {
    showToast(e?.message || "Failed to load patients", "error", 3600);
  } finally {
    patientsLoading.value = false;
  }
};

const openPatient = (p) => {
  const pid = Number(p.patientUserId || p.id) || 0;
  if (!pid) return;

  setActivePatientForViewer(user.value.id, { id: pid, fullName: p.fullName || "" });
  router.push(patientRecordsLink(pid));
};

const patientRecordsLink = (patientUserId) => {
  return { name: "records", query: { patientUserId: String(patientUserId) } };
};
const patientEncountersLink = (patientUserId) => {
  return { name: "encounters", query: { patientUserId: String(patientUserId) } };
};

const onRevokeByCode = async () => {
  if (!user.value?.id) return;

  busy.value = true;
  try {
    await revokeAccess({
      patientUserId: user.value.id,
      code: revokeCode.value.trim(),
    });

    showToast("Access revoked.", "success");
    revokeCode.value = "";
  } catch (e) {
    showToast(e?.message || "Failed to revoke access", "error", 3600);
  } finally {
    busy.value = false;
  }
};

onMounted(async () => {
  user.value = getSessionUser();

  // For clinician/student, load list immediately
  if (user.value?.id && (roleKey.value === "clinician" || roleKey.value === "student")) {
    await loadPatients();
  }
});
</script>
