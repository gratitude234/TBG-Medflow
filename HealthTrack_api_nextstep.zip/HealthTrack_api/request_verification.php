<?php
// public_html/HealthTrack_api/request_verification.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
$role = normalize_role((string)($me['role'] ?? 'patient'));
if ($role === 'patient') {
  json_response(['success'=>false,'error'=>'Patients do not need verification'],403);
}

$input = get_json_input();
$details = $input['details'] ?? null;
if ($details === null) {
  json_response(['success'=>false,'error'=>'details is required'],422);
}

try {
  $detailsJson = json_encode($details, JSON_UNESCAPED_SLASHES);
  if ($detailsJson === false) $detailsJson = '{"error":"invalid json"}';

  $pdo->beginTransaction();

  // Mark user pending
  $pdo->prepare("UPDATE users SET verification_status='pending' WHERE id=:id")
      ->execute([':id' => (int)$me['id']]);

  // Insert request
  $pdo->prepare("INSERT INTO verification_requests (user_id, role, details_json, status, created_at)
                 VALUES (:u, :r, :d, 'pending', NOW())")
      ->execute([':u' => (int)$me['id'], ':r' => $role, ':d' => $detailsJson]);

  $pdo->commit();

  json_response(['success'=>true, 'verificationStatus'=>'pending']);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  json_response(['success'=>false,'error'=>'Server error'],500);
}
