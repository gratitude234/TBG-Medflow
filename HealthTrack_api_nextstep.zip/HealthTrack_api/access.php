<?php
// public_html/HealthTrack_api/access.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';

function normalize_role(string $role): string {
    $r = strtolower(trim($role));
    return in_array($r, ['patient','student','clinician','other'], true) ? $r : 'patient';
}

/**
 * Patient can only access self.
 * Viewer roles can access if there is an active access_grants row.
 */
function require_patient_access(PDO $pdo, array $viewer, int $patientId): void {
    $viewerId = (int)($viewer['id'] ?? 0);
    $viewerRole = normalize_role((string)($viewer['role'] ?? 'patient'));

    if ($patientId <= 0) {
        json_response(['success' => false, 'error' => 'patientId is required'], 422);
    }

    // Patient/family: only self
    if ($viewerRole === 'patient') {
        if ($patientId !== $viewerId) {
            json_response(['success' => false, 'error' => 'Forbidden'], 403);
        }
        return;
    }

    // Clinician/student/other must have active grant
    $sql = "
      SELECT id
      FROM access_grants
      WHERE patient_user_id = :p
        AND viewer_user_id = :v
        AND status = 'active'
      LIMIT 1
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':p' => $patientId, ':v' => $viewerId]);
    $ok = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$ok) {
        json_response(['success' => false, 'error' => 'No access to this patient'], 403);
    }
}
