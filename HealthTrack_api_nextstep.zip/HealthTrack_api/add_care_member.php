<?php
// public_html/HealthTrack_api/add_care_member.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
require_role($me, ['patient']);

$input = get_json_input();
$viewerId = (int)($input['viewerUserId'] ?? 0);

if ($viewerId <= 0 || $viewerId === (int)$me['id']) {
    json_response(['success' => false, 'error' => 'Invalid care member'], 422);
}

try {
    $pdo->beginTransaction();

    // Validate viewer
    $stmt = $pdo->prepare("SELECT id, full_name, email, role, verification_status FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $viewerId]);
    $viewer = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$viewer) {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'User not found'], 404);
    }

    $viewerRole = normalize_role((string)$viewer['role']);
    if ($viewerRole === 'patient') {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'You can only add a clinician or student nurse'], 422);
    }

    $vs = strtolower((string)($viewer['verification_status'] ?? 'unverified'));
    if ($vs !== 'verified') {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'That account is not verified yet'], 409);
    }

    // Grant access
    $stmt = $pdo->prepare(
        "INSERT INTO access_grants (patient_user_id, viewer_user_id, viewer_role, status, created_at)
         VALUES (:p, :v, :vr, 'active', NOW())
         ON DUPLICATE KEY UPDATE
           viewer_role = VALUES(viewer_role),
           status = 'active',
           revoked_at = NULL"
    );
    $stmt->execute([
        ':p' => (int)$me['id'],
        ':v' => $viewerId,
        ':vr' => $viewerRole,
    ]);

    // Create thread
    $pdo->prepare(
        "INSERT INTO message_threads (patient_user_id, viewer_user_id, created_at)
         VALUES (:p, :v, NOW())
         ON DUPLICATE KEY UPDATE id = id"
    )->execute([
        ':p' => (int)$me['id'],
        ':v' => $viewerId,
    ]);

    $stmt = $pdo->prepare(
        "SELECT id FROM message_threads WHERE patient_user_id = :p AND viewer_user_id = :v LIMIT 1"
    );
    $stmt->execute([
        ':p' => (int)$me['id'],
        ':v' => $viewerId,
    ]);
    $threadId = (int)($stmt->fetchColumn() ?: 0);

    // Notify viewer
    notify_user(
        $pdo,
        $viewerId,
        (int)$me['id'],
        'care_team_added',
        'New patient shared access',
        (string)$me['fullName'] . ' added you to their care team.',
        '/inbox',
        ['patientUserId' => (int)$me['id'], 'threadId' => $threadId]
    );

    $pdo->commit();

    json_response([
        'success' => true,
        'threadId' => $threadId,
        'careMember' => [
            'id' => (int)$viewer['id'],
            'fullName' => (string)$viewer['full_name'],
            'email' => (string)$viewer['email'],
            'role' => $viewerRole,
        ],
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
