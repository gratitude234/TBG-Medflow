<?php
// public_html/HealthTrack_api/get_encounters.php
declare(strict_types=1);

// Alias for list_encounters.php (kept for backward compatibility)
require __DIR__ . '/list_encounters.php';
