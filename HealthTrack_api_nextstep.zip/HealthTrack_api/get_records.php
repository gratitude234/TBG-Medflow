<?php
// public_html/HealthTrack_api/get_records.php
declare(strict_types=1);

// Alias for list_records.php (kept for backward compatibility)
require __DIR__ . '/list_records.php';
