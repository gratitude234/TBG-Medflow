<?php
// public_html/HealthTrack_api/share_record.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
require_role($me, ['patient']);

$input = get_json_input();
$viewerId = (int)($input['viewerUserId'] ?? 0);
$recordId = (int)($input['recordId'] ?? 0);
$note = trim((string)($input['note'] ?? ''));

if ($viewerId <= 0) {
  json_response(['success'=>false,'error'=>'viewerUserId is required'],422);
}

try {
  $pdo->beginTransaction();

  $stmt = $pdo->prepare("SELECT id, full_name, role, verification_status FROM users WHERE id=:id LIMIT 1");
  $stmt->execute([':id' => $viewerId]);
  $viewer = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$viewer) {
    $pdo->rollBack();
    json_response(['success'=>false,'error'=>'Clinician/student not found'],404);
  }

  $viewerRole = strtolower((string)$viewer['role']);
  if ($viewerRole === 'patient') {
    $pdo->rollBack();
    json_response(['success'=>false,'error'=>'You can only share to a clinician/student'],422);
  }

  $vs = strtolower((string)($viewer['verification_status'] ?? 'unverified'));
  if ($vs !== 'verified') {
    $pdo->rollBack();
    json_response(['success'=>false,'error'=>'Selected clinician/student is not verified yet'],409);
  }

  // Ensure access grant is active
  $pdo->prepare("\
    INSERT INTO access_grants (patient_user_id, viewer_user_id, viewer_role, status, created_at)
    VALUES (:p, :v, :vr, 'active', NOW())
    ON DUPLICATE KEY UPDATE status='active', viewer_role=VALUES(viewer_role), revoked_at=NULL
  ")->execute([
    ':p' => (int)$me['id'],
    ':v' => $viewerId,
    ':vr'=> $viewerRole,
  ]);

  // If recordId not provided, share latest
  if ($recordId <= 0) {
    $stmt = $pdo->prepare("SELECT id FROM health_records WHERE user_id=:u ORDER BY record_date DESC, id DESC LIMIT 1");
    $stmt->execute([':u' => (int)$me['id']]);
    $recordId = (int)($stmt->fetchColumn() ?: 0);
  }

  if ($recordId <= 0) {
    $pdo->rollBack();
    json_response(['success'=>false,'error'=>'No record found to share'],404);
  }

  // Confirm record belongs to patient
  $stmt = $pdo->prepare("SELECT 1 FROM health_records WHERE id=:rid AND user_id=:u LIMIT 1");
  $stmt->execute([':rid' => $recordId, ':u' => (int)$me['id']]);
  if (!$stmt->fetchColumn()) {
    $pdo->rollBack();
    json_response(['success'=>false,'error'=>'Record not found'],404);
  }

  // Track share (idempotent)
  $pdo->prepare("\
    INSERT INTO record_shares (record_id, patient_user_id, viewer_user_id, note, created_at)
    VALUES (:rid, :p, :v, :n, NOW())
    ON DUPLICATE KEY UPDATE note=VALUES(note), created_at=NOW()
  ")->execute([
    ':rid' => $recordId,
    ':p' => (int)$me['id'],
    ':v' => $viewerId,
    ':n' => ($note === '' ? null : $note),
  ]);

  // Ensure thread exists
  $pdo->prepare("\
    INSERT INTO message_threads (patient_user_id, viewer_user_id, created_at)
    VALUES (:p, :v, NOW())
    ON DUPLICATE KEY UPDATE patient_user_id=patient_user_id
  ")->execute([':p'=>(int)$me['id'], ':v'=>$viewerId]);

  $stmt = $pdo->prepare("SELECT id FROM message_threads WHERE patient_user_id=:p AND viewer_user_id=:v LIMIT 1");
  $stmt->execute([':p'=>(int)$me['id'], ':v'=>$viewerId]);
  $threadId = (int)($stmt->fetchColumn() ?: 0);

  notify_user(
    $pdo,
    $viewerId,
    (int)$me['id'],
    'record_shared',
    'New record shared',
    ((string)$me['fullName']) . ' shared a record with you.',
    $threadId > 0 ? ('/inbox/' . $threadId) : '/inbox',
    ['recordId' => $recordId, 'threadId' => $threadId]
  );

  $pdo->commit();

  json_response([
    'success' => true,
    'recordId' => $recordId,
    'viewerUserId' => $viewerId,
    'threadId' => $threadId,
  ]);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  json_response(['success'=>false,'error'=>'Server error'],500);
}
