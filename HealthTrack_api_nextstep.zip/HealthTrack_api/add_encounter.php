<?php
// public_html/HealthTrack_api/add_encounter.php
declare(strict_types=1);

require __DIR__ . '/config.php';
require_once __DIR__ . '/response.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/access.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
$authorUserId = (int)$me['id'];
$authorRole   = normalize_role((string)$me['role']);

$input = get_json_input();

// Backward compatible: allow userId but prefer patientUserId
$patientUserId = (int)($input['patientUserId'] ?? 0);
if ($patientUserId <= 0) $patientUserId = (int)($input['userId'] ?? 0);
if ($patientUserId <= 0) $patientUserId = (int)($input['user_id'] ?? 0);

$encounterDate = trim((string)($input['date'] ?? ''));
$encounterTime = $input['time'] ?? null;
$session       = $input['session'] ?? null;

$chiefComplaint = trim((string)($input['chiefComplaint'] ?? ''));
$subjective     = $input['subjective'] ?? null;
$objective      = $input['objective'] ?? null;
$assessment     = $input['assessment'] ?? null;
$plan           = $input['plan'] ?? null;
$followUpDate   = $input['followUpDate'] ?? null;

// For MVP:
$status = strtolower(trim((string)($input['status'] ?? 'draft')));

if ($patientUserId <= 0) {
    json_response(['success' => false, 'error' => 'Missing patientUserId'], 422);
}
if ($encounterDate === '') {
    json_response(['success' => false, 'error' => 'Date is required'], 422);
}
if ($chiefComplaint === '') {
    json_response(['success' => false, 'error' => 'Chief complaint is required'], 422);
}

// Permission check: patient self-only; others require access grant
require_patient_access($pdo, $me, $patientUserId);

// Status rules (simple + clinic-friendly)
$allowedStatus = ['draft','submitted','approved'];
if (!in_array($status, $allowedStatus, true)) $status = 'draft';

// Only clinicians can approve (optional but recommended)
if ($status === 'approved' && $authorRole !== 'clinician') {
    $status = 'submitted';
}

// Patients can't submit/approve; keep as draft unless you want otherwise
if ($authorRole === 'patient' && $status !== 'draft') {
    $status = 'draft';
}

// Normalize empty strings → null
$encounterTime = ($encounterTime === '' ? null : $encounterTime);
$session       = ($session === '' ? null : $session);
$followUpDate  = ($followUpDate === '' ? null : $followUpDate);

try {
    $stmt = $pdo->prepare("
        INSERT INTO encounters (
          patient_user_id,
          author_user_id,
          author_role,
          encounter_date,
          encounter_time,
          session,
          chief_complaint,
          subjective,
          objective,
          assessment,
          plan,
          follow_up_date,
          status
        ) VALUES (
          :patient_user_id,
          :author_user_id,
          :author_role,
          :encounter_date,
          :encounter_time,
          :session,
          :chief_complaint,
          :subjective,
          :objective,
          :assessment,
          :plan,
          :follow_up_date,
          :status
        )
    ");

    $stmt->execute([
        ':patient_user_id'  => $patientUserId,
        ':author_user_id'   => $authorUserId,
        ':author_role'      => $authorRole,
        ':encounter_date'   => $encounterDate,
        ':encounter_time'   => $encounterTime,
        ':session'          => $session,
        ':chief_complaint'  => $chiefComplaint,
        ':subjective'       => ($subjective === '' ? null : $subjective),
        ':objective'        => ($objective === '' ? null : $objective),
        ':assessment'       => ($assessment === '' ? null : $assessment),
        ':plan'             => ($plan === '' ? null : $plan),
        ':follow_up_date'   => $followUpDate,
        ':status'           => $status,
    ]);

    json_response([
        'success' => true,
        'message' => 'Encounter saved',
        'id'      => (int)$pdo->lastInsertId(),
        'patientUserId' => $patientUserId,
        'author' => [
            'id' => $authorUserId,
            'role' => $authorRole,
        ],
        'status' => $status,
    ]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
