<?php
// public_html/HealthTrack_api/list_verification_requests.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$user = require_auth($pdo);

// Admin check (MVP): role OR allowlisted email
$role = strtolower((string)($user['role'] ?? ''));
$allowedRoles = ['admin', 'super_admin'];
$allowed = in_array($role, $allowedRoles, true);

if (!$allowed) {
    global $ADMIN_EMAILS;
    $allowed = is_array($ADMIN_EMAILS) && in_array(strtolower((string)($user['email'] ?? '')), array_map('strtolower', $ADMIN_EMAILS), true);
}

if (!$allowed) {
    json_response(['success' => false, 'error' => 'Forbidden'], 403);
}

$status = strtolower(trim((string)($_GET['status'] ?? 'pending')));
$limit  = (int)($_GET['limit'] ?? 50);
$limit  = max(1, min($limit, 200));

$where = '';
$params = [];
if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
    $where = 'WHERE vr.status = :st';
    $params[':st'] = $status;
}

$sql = "
  SELECT
    vr.id,
    vr.user_id,
    vr.role AS requested_role,
    vr.details_json,
    vr.status,
    vr.created_at,
    vr.updated_at,
    vr.reviewed_by_user_id,
    vr.reviewed_at,
    vr.review_note,
    u.full_name,
    u.email,
    u.role AS user_role,
    u.verification_status
  FROM verification_requests vr
  JOIN users u ON u.id = vr.user_id
  $where
  ORDER BY vr.created_at DESC
  LIMIT $limit
";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $out = [];
    foreach ($rows as $r) {
        $details = null;
        if (!empty($r['details_json'])) {
            $decoded = json_decode((string)$r['details_json'], true);
            if (is_array($decoded)) $details = $decoded;
        }

        $out[] = [
            'id' => (int)$r['id'],
            'userId' => (int)$r['user_id'],
            'requestedRole' => (string)$r['requested_role'],
            'status' => (string)$r['status'],
            'createdAt' => (string)$r['created_at'],
            'updatedAt' => $r['updated_at'] ? (string)$r['updated_at'] : null,
            'reviewedByUserId' => $r['reviewed_by_user_id'] ? (int)$r['reviewed_by_user_id'] : null,
            'reviewedAt' => $r['reviewed_at'] ? (string)$r['reviewed_at'] : null,
            'reviewNote' => $r['review_note'] ? (string)$r['review_note'] : null,
            'user' => [
                'id' => (int)$r['user_id'],
                'fullName' => (string)$r['full_name'],
                'email' => (string)$r['email'],
                'role' => (string)$r['user_role'],
                'verificationStatus' => (string)($r['verification_status'] ?? 'unverified'),
            ],
            'details' => $details,
        ];
    }

    json_response([
        'success' => true,
        'items' => $out,
    ]);
} catch (Throwable $e) {
    error_log('[list_verification_requests] ' . $e->getMessage());
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
