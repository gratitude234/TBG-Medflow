<?php
// public_html/HealthTrack_api/list_encounters.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/access.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);

$input = [];
if ($method === 'POST') $input = get_json_input();

// Backward compatible: patientUserId OR userId/user_id
$patientUserId =
    (int)($input['patientUserId'] ?? 0) ? (int)$input['patientUserId'] :
    ((int)($_GET['patientUserId'] ?? 0) ? (int)$_GET['patientUserId'] :
    ((int)($input['userId'] ?? 0) ? (int)$input['userId'] :
    ((int)($input['user_id'] ?? 0) ? (int)$input['user_id'] :
    ((int)($_GET['userId'] ?? 0) ? (int)$_GET['userId'] :
    (int)($_GET['user_id'] ?? 0)))));

// Default: if not provided, list own encounters
if ($patientUserId <= 0) {
    $patientUserId = (int)$me['id'];
}

// Permission check
require_patient_access($pdo, $me, $patientUserId);

// Optional limit
$limit = 0;
if (isset($input['limit'])) $limit = (int)$input['limit'];
if (isset($_GET['limit'])) $limit = (int)$_GET['limit'];

if ($limit < 0) $limit = 0;
if ($limit > 200) $limit = 200;

try {
    $sql = "
      SELECT
        id,
        patient_user_id,
        author_user_id,
        author_role,
        encounter_date,
        encounter_time,
        session,
        chief_complaint,
        subjective,
        objective,
        assessment,
        plan,
        follow_up_date,
        status,
        created_at
      FROM encounters
      WHERE patient_user_id = :patient_user_id
      ORDER BY encounter_date DESC, encounter_time DESC, created_at DESC
    ";

    if ($limit > 0) {
        $sql .= " LIMIT :limit";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':patient_user_id', $patientUserId, PDO::PARAM_INT);
    if ($limit > 0) $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);

    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    json_response([
        'success' => true,
        'patientUserId' => $patientUserId,
        'encounters' => $rows
    ]);
} catch (Throwable $e) {
    $debug = true; // set false later
    json_response(['success' => false, 'error' => $debug ? $e->getMessage() : 'Server error'], 500);
}
