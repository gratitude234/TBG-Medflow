<?php
// public_html/HealthTrack_api/submit_verification_request.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$actor = require_auth($pdo);

$role = strtolower((string)($actor['role'] ?? ''));
if (!in_array($role, ['student', 'clinician'], true)) {
    json_response(['success' => false, 'error' => 'Only student nurses and clinicians can submit verification requests.'], 403);
}

$input = get_json_input();

$note = trim((string)($input['note'] ?? ''));
$documentUrl = trim((string)($input['documentUrl'] ?? $input['document_url'] ?? ''));

$details = $input['details'] ?? null;
if ($details && !is_array($details)) {
    $details = null;
}

$detailsJson = [
    'note' => $note,
    'documentUrl' => $documentUrl,
    'extra' => $details,
];

try {
    // If already verified, nothing to do.
    if (users_column_exists($pdo, 'verification_status')) {
        $stmt = $pdo->prepare("SELECT verification_status FROM users WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => (int)$actor['id']]);
        $vs = (string)($stmt->fetchColumn() ?: 'unverified');
        if ($vs === 'verified') {
            json_response(['success' => true, 'message' => 'Already verified.', 'verificationStatus' => 'verified']);
        }
    }

    // Upsert pending request per user.
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT id, status FROM verification_requests WHERE user_id = :uid ORDER BY id DESC LIMIT 1");
    $stmt->execute([':uid' => (int)$actor['id']]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing && (string)$existing['status'] === 'pending') {
        $stmt = $pdo->prepare("UPDATE verification_requests
                               SET details_json = :dj, updated_at = NOW()
                               WHERE id = :id");
        $stmt->execute([
            ':dj' => json_encode($detailsJson, JSON_UNESCAPED_SLASHES),
            ':id' => (int)$existing['id'],
        ]);
        $requestId = (int)$existing['id'];
    } else {
        $stmt = $pdo->prepare("INSERT INTO verification_requests (user_id, role, details_json, status, created_at)
                               VALUES (:uid, :role, :dj, 'pending', NOW())");
        $stmt->execute([
            ':uid' => (int)$actor['id'],
            ':role' => $role,
            ':dj' => json_encode($detailsJson, JSON_UNESCAPED_SLASHES),
        ]);
        $requestId = (int)$pdo->lastInsertId();
    }

    // Mark user as pending (if column exists)
    if (users_column_exists($pdo, 'verification_status')) {
        $stmt = $pdo->prepare("UPDATE users SET verification_status = 'pending', verification_note = :n WHERE id = :id");
        $stmt->execute([
            ':n' => $note !== '' ? $note : null,
            ':id' => (int)$actor['id'],
        ]);
    }

    $pdo->commit();

    // Notify admins (best-effort)
    try {
        global $ADMIN_EMAILS;
        $adminEmails = is_array($ADMIN_EMAILS) ? $ADMIN_EMAILS : [];
        if (count($adminEmails) > 0 && users_column_exists($pdo, 'verification_status')) {
            $placeholders = implode(',', array_fill(0, count($adminEmails), '?'));
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email IN ($placeholders) LIMIT 50");
            $stmt->execute($adminEmails);
            $admins = $stmt->fetchAll(PDO::FETCH_COLUMN);

            foreach ($admins as $adminId) {
                $pdo->prepare("INSERT INTO notifications (user_id, actor_user_id, type, title, body, link, created_at)
                               VALUES (:uid, :actor, 'verification_request', :t, :b, :l, NOW())")
                    ->execute([
                        ':uid' => (int)$adminId,
                        ':actor' => (int)$actor['id'],
                        ':t' => 'New verification request',
                        ':b' => ($actor['fullName'] ?? 'A user') . ' submitted a verification request.',
                        ':l' => '/admin/verification',
                    ]);
            }
        }
    } catch (Throwable $e) {
        // ignore
    }

    json_response([
        'success' => true,
        'requestId' => $requestId,
        'verificationStatus' => 'pending',
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[submit_verification_request] ' . $e->getMessage());
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
