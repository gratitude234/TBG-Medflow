<?php
// public_html/HealthTrack_api/revoke_access.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
$role = strtolower((string)$me['role']);
if ($role !== 'patient') {
    json_response(['success' => false, 'error' => 'Only patients can revoke access'], 403);
}

$input = get_json_input();

$viewerUserId = (int)($input['viewerUserId'] ?? 0);
$code = strtoupper(trim((string)($input['code'] ?? '')));

if ($viewerUserId <= 0 && $code === '') {
    json_response(['success' => false, 'error' => 'viewerUserId or code is required'], 422);
}

try {
    // Revoke a viewer grant
    if ($viewerUserId > 0) {
        $stmt = $pdo->prepare("
          UPDATE access_grants
          SET status='revoked', revoked_at=NOW()
          WHERE patient_user_id = :p
            AND viewer_user_id = :v
            AND status = 'active'
        ");
        $stmt->execute([
            ':p' => (int)$me['id'],
            ':v' => $viewerUserId,
        ]);

        json_response([
            'success' => true,
            'message' => ($stmt->rowCount() > 0) ? 'Access revoked' : 'No active access found',
        ]);
    }

    // Revoke an unused invite code
    $stmt = $pdo->prepare("
      UPDATE share_invites
      SET status='revoked'
      WHERE patient_user_id = :p
        AND code = :c
        AND status = 'active'
    ");
    $stmt->execute([
        ':p' => (int)$me['id'],
        ':c' => $code,
    ]);

    json_response([
        'success' => true,
        'message' => ($stmt->rowCount() > 0) ? 'Invite revoked' : 'No active invite found',
    ]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
