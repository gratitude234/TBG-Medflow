<?php
// public_html/HealthTrack_api/register.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = get_json_input();

$fullName = trim((string)($input['fullName'] ?? ''));
$email    = trim((string)($input['email'] ?? ''));
$password = (string)($input['password'] ?? '');
$role     = (string)($input['role'] ?? 'patient');

if ($fullName === '') {
    json_response(['success' => false, 'error' => 'Full name is required'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['success' => false, 'error' => 'Valid email is required'], 422);
}
if (strlen($password) < 6) {
    json_response(['success' => false, 'error' => 'Password must be at least 6 characters'], 422);
}

$allowedRoles = ['patient', 'student', 'clinician', 'other'];
if (!in_array($role, $allowedRoles, true)) {
    $role = 'patient';
}

/**
 * Checks if a column exists in the `users` table.
 */
function users_column_exists(PDO $pdo, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'users'
          AND COLUMN_NAME = :col
        LIMIT 1
    ");
    $stmt->execute([':col' => $column]);
    return (bool)$stmt->fetchColumn();
}

/**
 * Stores a bearer token in user_tokens (hashed).
 */
function store_user_token(PDO $pdo, int $userId, string $rawToken, ?string $expiresAt = null): void
{
    $hash = hash('sha256', $rawToken);

    $stmt = $pdo->prepare("
        INSERT INTO user_tokens (user_id, token_hash, created_at, expires_at, last_used_at, revoked)
        VALUES (:uid, :th, NOW(), :exp, NOW(), 0)
    ");
    $stmt->execute([
        ':uid' => $userId,
        ':th'  => $hash,
        ':exp' => $expiresAt,
    ]);
}

try {
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        json_response(['success' => false, 'error' => 'Email already registered'], 409);
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $hasOnboarding = users_column_exists($pdo, 'onboarding_complete');
    $hasVerification = users_column_exists($pdo, 'verification_status');

    // Verification default:
    // - patients auto-verified
    // - student/clinician/other start as unverified (they can request verification)
    $verificationStatus = ($role === 'patient') ? 'verified' : 'unverified';

    // Build insert dynamically to remain backward-compatible when columns are missing.
    if ($hasOnboarding && $hasVerification) {
        $stmt = $pdo->prepare(
            'INSERT INTO users (full_name, email, password_hash, role, verification_status, onboarding_complete)
             VALUES (:full_name, :email, :password_hash, :role, :verification_status, 0)'
        );
    } elseif ($hasOnboarding) {
        $stmt = $pdo->prepare(
            'INSERT INTO users (full_name, email, password_hash, role, onboarding_complete)
             VALUES (:full_name, :email, :password_hash, :role, 0)'
        );
    } elseif ($hasVerification) {
        $stmt = $pdo->prepare(
            'INSERT INTO users (full_name, email, password_hash, role, verification_status)
             VALUES (:full_name, :email, :password_hash, :role, :verification_status)'
        );
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO users (full_name, email, password_hash, role)
             VALUES (:full_name, :email, :password_hash, :role)'
        );
    }

    $params = [
        ':full_name'     => $fullName,
        ':email'         => $email,
        ':password_hash' => $hash,
        ':role'          => $role,
    ];
    if ($hasVerification) {
        $params[':verification_status'] = $verificationStatus;
    }
    $stmt->execute($params);

    $userId = (int)$pdo->lastInsertId();

    // Issue token immediately (helps frontend keep flow consistent)
    $token = bin2hex(random_bytes(16));
    $expiresAt = date('Y-m-d H:i:s', time() + (14 * 24 * 3600));

    // Store token
    store_user_token($pdo, $userId, $token, $expiresAt);

    json_response([
        'success' => true,
        'token'   => $token,
        'expiresAt' => $expiresAt,
        'user'    => [
            'id'                 => $userId,
            'fullName'           => $fullName,
            'email'              => $email,
            'role'               => $role,
            'onboardingComplete' => false,
            'verificationStatus' => $hasVerification ? $verificationStatus : 'unverified',
            'createdAt'          => date('Y-m-d H:i:s'),
        ],
    ]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
