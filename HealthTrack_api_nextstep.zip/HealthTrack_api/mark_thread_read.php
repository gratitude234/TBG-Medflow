<?php
// public_html/HealthTrack_api/mark_thread_read.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
$role = normalize_role((string)($me['role'] ?? 'patient'));
if ($role !== 'patient') require_verified_staff($me);

$input = get_json_input();
$threadId = (int)($input['threadId'] ?? 0);
if ($threadId <= 0) json_response(['success'=>false,'error'=>'threadId is required'],422);

try {
  if ($role === 'patient') {
    $stmt = $pdo->prepare("UPDATE message_threads SET patient_last_read_at=NOW() WHERE id=:id AND patient_user_id=:u");
    $stmt->execute([':id'=>$threadId, ':u'=>(int)$me['id']]);
  } else {
    $stmt = $pdo->prepare("UPDATE message_threads SET viewer_last_read_at=NOW() WHERE id=:id AND viewer_user_id=:u");
    $stmt->execute([':id'=>$threadId, ':u'=>(int)$me['id']]);
  }

  json_response(['success'=>true]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
