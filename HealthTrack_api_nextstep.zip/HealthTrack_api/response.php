<?php
// public_html/HealthTrack_api/response.php
declare(strict_types=1);

// Prevent accidental double-includes from redeclaring functions
if (!defined('HEALTHTRACK_RESPONSE_LOADED')) {
    define('HEALTHTRACK_RESPONSE_LOADED', true);

    // --------------------------------------------------
    // CORS + Preflight (shared by ALL endpoints)
    // --------------------------------------------------
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Max-Age: 86400');

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// --------------------------------------------------
// Helpers (guarded)
// --------------------------------------------------
if (!function_exists('json_response')) {
    function json_response(array $data, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('get_json_input')) {
    function get_json_input(): array {
        $raw = file_get_contents('php://input');
        if ($raw === false || trim($raw) === '') return [];

        $data = json_decode($raw, true);

        // If invalid JSON, return error
        if (!is_array($data)) {
            json_response(['success' => false, 'error' => 'Invalid JSON body'], 400);
        }
        return $data;
    }
}
