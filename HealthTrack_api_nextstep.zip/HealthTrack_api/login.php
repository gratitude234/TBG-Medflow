<?php
// public_html/HealthTrack_api/login.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = get_json_input();

$email    = trim((string)($input['email'] ?? ''));
$password = (string)($input['password'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_response(['success' => false, 'error' => 'Valid email is required'], 422);
}
if ($password === '') {
    json_response(['success' => false, 'error' => 'Password is required'], 422);
}

/**
 * Checks if a column exists in the `users` table.
 * Uses DATABASE() so it works without needing schema name.
 */
function users_column_exists(PDO $pdo, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'users'
          AND COLUMN_NAME = :col
        LIMIT 1
    ");
    $stmt->execute([':col' => $column]);
    return (bool)$stmt->fetchColumn();
}

/**
 * Stores a bearer token in user_tokens (hashed).
 */
function store_user_token(PDO $pdo, int $userId, string $rawToken, ?string $expiresAt = null): void
{
    // Store sha256 hash, not raw token
    $hash = hash('sha256', $rawToken);

    $stmt = $pdo->prepare("
        INSERT INTO user_tokens (user_id, token_hash, created_at, expires_at, last_used_at, revoked)
        VALUES (:uid, :th, NOW(), :exp, NOW(), 0)
    ");
    $stmt->execute([
        ':uid' => $userId,
        ':th'  => $hash,
        ':exp' => $expiresAt, // can be null
    ]);
}

try {
    $hasOnboarding = users_column_exists($pdo, 'onboarding_complete');
    $hasVerification = users_column_exists($pdo, 'verification_status');

    if ($hasOnboarding && $hasVerification) {
        $sql = 'SELECT id, full_name, email, password_hash, role, onboarding_complete, verification_status, created_at
                FROM users
                WHERE email = ?
                LIMIT 1';
    } elseif ($hasOnboarding) {
        $sql = 'SELECT id, full_name, email, password_hash, role, onboarding_complete, created_at
                FROM users
                WHERE email = ?
                LIMIT 1';
    } elseif ($hasVerification) {
        $sql = 'SELECT id, full_name, email, password_hash, role, verification_status, created_at
                FROM users
                WHERE email = ?
                LIMIT 1';
    } else {
        $sql = 'SELECT id, full_name, email, password_hash, role, created_at
                FROM users
                WHERE email = ?
                LIMIT 1';
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, (string)$user['password_hash'])) {
        json_response(['success' => false, 'error' => 'Invalid email or password'], 401);
    }

    // MVP token
    $token = bin2hex(random_bytes(16));

    // Optional expiry: 14 days (recommended)
    $expiresAt = date('Y-m-d H:i:s', time() + (14 * 24 * 3600));

    // Store token so other endpoints can authenticate Bearer
    store_user_token($pdo, (int)$user['id'], $token, $expiresAt);

    $onboardingComplete = $hasOnboarding ? (((int)($user['onboarding_complete'] ?? 0)) === 1) : false;
    $verificationStatus = $hasVerification ? (string)($user['verification_status'] ?? 'unverified') : 'unverified';

    json_response([
        'success' => true,
        'token'   => $token,
        'expiresAt' => $expiresAt,
        'user'    => [
            'id'                 => (int)$user['id'],
            'fullName'           => (string)$user['full_name'],
            'email'              => (string)$user['email'],
            'role'               => (string)$user['role'],
            'onboardingComplete' => $onboardingComplete,
            'verificationStatus' => $verificationStatus,
            'createdAt'          => (string)$user['created_at'],
        ],
    ]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
