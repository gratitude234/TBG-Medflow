<?php
// public_html/HealthTrack_api/add_record.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/access.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
$viewerId = (int)$me['id'];
$viewerRole = normalize_role((string)$me['role']);

$input = get_json_input();

// Backward compatible: allow userId/user_id, but preferred is patientUserId
$patientUserId =
    ((int)($input['patientUserId'] ?? 0) > 0) ? (int)$input['patientUserId'] :
    (((int)($input['userId'] ?? 0) > 0) ? (int)$input['userId'] :
    (int)($input['user_id'] ?? 0));

$recordDate = trim((string)($input['date'] ?? ''));
$recordTime = $input['time'] ?? null;
$session    = $input['session'] ?? null;

$bpSys   = $input['bpSystolic'] ?? null;
$bpDia   = $input['bpDiastolic'] ?? null;
$heart   = $input['heartRate'] ?? null;
$temp    = $input['temperature'] ?? null;
$sugar   = $input['bloodSugar'] ?? null;

$symptoms = trim((string)($input['symptoms'] ?? ''));
$notes    = trim((string)($input['notes'] ?? ''));

$takenMedication    = !empty($input['takenMedication']) ? 1 : 0;
$fasting            = !empty($input['fasting']) ? 1 : 0;
$shareWithClinician = !empty($input['shareWithClinician']) ? 1 : 0;

if ($patientUserId <= 0) {
    json_response(['success' => false, 'error' => 'Missing patientUserId'], 422);
}
if ($recordDate === '') {
    json_response(['success' => false, 'error' => 'Date is required'], 422);
}

// robust "has value" check (handles 0 correctly)
$hasValue = static fn($v): bool => !($v === null || $v === '');

// Must have at least one vital
$hasAnyVitals =
    $hasValue($bpSys) ||
    $hasValue($bpDia) ||
    $hasValue($heart) ||
    $hasValue($temp) ||
    $hasValue($sugar);

if (!$hasAnyVitals) {
    json_response(['success' => false, 'error' => 'Add at least one vital'], 422);
}

// ✅ LOG: endpoint hit
error_log("[add_record] hit viewerId={$viewerId} role={$viewerRole} patientUserId={$patientUserId} date={$recordDate}");

// Permission check: patient self-only; others require access grant
require_patient_access($pdo, $me, $patientUserId);

// Optional: only patient can set shareWithClinician
if ($viewerRole !== 'patient') {
    $shareWithClinician = 0;
}

try {
    $stmt = $pdo->prepare(
        'INSERT INTO health_records (
            user_id,
            entered_by_user_id,
            entered_by_role,
            record_date,
            record_time,
            session,
            bp_systolic,
            bp_diastolic,
            heart_rate,
            temperature,
            blood_sugar,
            symptoms,
            notes,
            taken_medication,
            fasting,
            share_with_clinician
        ) VALUES (
            :patient_user_id,
            :entered_by_user_id,
            :entered_by_role,
            :record_date,
            :record_time,
            :session,
            :bp_systolic,
            :bp_diastolic,
            :heart_rate,
            :temperature,
            :blood_sugar,
            :symptoms,
            :notes,
            :taken_medication,
            :fasting,
            :share_with_clinician
        )'
    );

    $ok = $stmt->execute([
        ':patient_user_id'       => $patientUserId,
        ':entered_by_user_id'    => $viewerId,
        ':entered_by_role'       => $viewerRole,
        ':record_date'           => $recordDate,
        ':record_time'           => $hasValue($recordTime) ? $recordTime : null,
        ':session'               => $hasValue($session) ? $session : null,
        ':bp_systolic'           => $hasValue($bpSys) ? $bpSys : null,
        ':bp_diastolic'          => $hasValue($bpDia) ? $bpDia : null,
        ':heart_rate'            => $hasValue($heart) ? $heart : null,
        ':temperature'           => $hasValue($temp) ? $temp : null,
        ':blood_sugar'           => $hasValue($sugar) ? $sugar : null,
        ':symptoms'              => $symptoms !== '' ? $symptoms : null,
        ':notes'                 => $notes !== '' ? $notes : null,
        ':taken_medication'      => $takenMedication,
        ':fasting'               => $fasting,
        ':share_with_clinician'  => $shareWithClinician,
    ]);

    // ✅ If execute returns false (rare if exceptions enabled), log + fail clearly
    if ($ok !== true) {
        $err = $stmt->errorInfo();
        error_log("[add_record] execute returned false: " . json_encode($err));
        json_response(['success' => false, 'error' => 'Insert failed'], 500);
    }

    $recordId = (int)$pdo->lastInsertId();

    // ✅ If recordId is 0, something is wrong (log it)
    if ($recordId <= 0) {
        error_log("[add_record] lastInsertId returned 0 (unexpected).");
        json_response(['success' => false, 'error' => 'Insert failed (no record id)'], 500);
    }

    json_response([
        'success'  => true,
        'message'  => 'Record saved',
        'recordId' => $recordId,
        'patientUserId' => $patientUserId,
        'enteredBy' => [
            'id' => $viewerId,
            'role' => $viewerRole,
        ],
    ], 201);

} catch (Throwable $e) {
    // ✅ log real DB error so we can see it inside error_log
    error_log("[add_record] exception: " . $e->getMessage());
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
