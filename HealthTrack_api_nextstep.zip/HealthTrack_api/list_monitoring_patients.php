<?php
// public_html/HealthTrack_api/list_monitoring_patients.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
$role = strtolower((string)$me['role']);

if ($role === 'patient') {
    json_response(['success' => false, 'error' => 'Patients do not have a monitoring list'], 403);
}

try {
    $sql = "
      SELECT
        u.id        AS patientUserId,
        u.full_name AS fullName,
        u.email     AS email,
        (
          SELECT MAX(hr.record_date)
          FROM health_records hr
          WHERE hr.user_id = u.id
        ) AS lastRecordDate,
        (
          SELECT MAX(CONCAT(e.encounter_date, ' ', COALESCE(e.encounter_time, '00:00:00')))
          FROM encounters e
          WHERE e.patient_user_id = u.id
        ) AS lastEncounterAt
      FROM access_grants ag
      JOIN users u ON u.id = ag.patient_user_id
      WHERE ag.viewer_user_id = :viewer
        AND ag.status = 'active'
      ORDER BY
        COALESCE(lastEncounterAt, '1970-01-01 00:00:00') DESC,
        COALESCE(lastRecordDate, '1970-01-01') DESC,
        u.full_name ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':viewer' => (int)$me['id']]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    json_response(['success' => true, 'patients' => $rows]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
