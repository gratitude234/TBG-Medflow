<?php
// public_html/HealthTrack_api/me.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$user = require_auth($pdo);

json_response([
    'success' => true,
    'user' => $user,
]);
