<?php
// public_html/HealthTrack_api/search_verified_staff.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
require_role($me, ['patient']);

$q = trim((string)($_GET['q'] ?? ''));
$limit = (int)($_GET['limit'] ?? 20);
if ($limit < 1) $limit = 20;
if ($limit > 50) $limit = 50;

try {
    $like = '%' . $q . '%';

    $sql = "
      SELECT id, full_name AS fullName, email, role, verification_status AS verificationStatus
      FROM users
      WHERE role IN ('student','clinician')
        AND verification_status = 'verified'
        AND (
          :q = ''
          OR full_name LIKE :like
          OR email LIKE :like
        )
      ORDER BY full_name ASC
      LIMIT $limit
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':q' => $q,
        ':like' => $like,
    ]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    json_response(['success' => true, 'staff' => $rows]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
