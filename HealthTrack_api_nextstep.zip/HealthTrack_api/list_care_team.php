<?php
// public_html/HealthTrack_api/list_care_team.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
require_role($me, ['patient']);

try {
    $stmt = $pdo->prepare(
        "SELECT
            ag.viewer_user_id AS viewerUserId,
            u.full_name AS fullName,
            u.email AS email,
            u.role AS role,
            ag.status AS status,
            ag.created_at AS grantedAt,
            t.id AS threadId,
            t.last_message_at AS lastMessageAt,
            t.last_message_preview AS lastMessagePreview
        FROM access_grants ag
        JOIN users u ON u.id = ag.viewer_user_id
        LEFT JOIN message_threads t ON t.patient_user_id = ag.patient_user_id AND t.viewer_user_id = ag.viewer_user_id
        WHERE ag.patient_user_id = :p
          AND ag.status = 'active'
        ORDER BY u.full_name ASC"
    );
    $stmt->execute([':p' => (int)$me['id']]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    json_response(['success' => true, 'careTeam' => $rows, 'members' => $rows]);
} catch (Throwable $e) {
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
