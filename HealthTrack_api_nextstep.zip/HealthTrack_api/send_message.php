<?php
// public_html/HealthTrack_api/send_message.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
$role = normalize_role((string)($me['role'] ?? 'patient'));
if ($role !== 'patient') {
  require_verified_staff($me);
}

$input = get_json_input();
$threadId = (int)($input['threadId'] ?? 0);
$body = trim((string)($input['body'] ?? ''));

if ($threadId <= 0) json_response(['success'=>false,'error'=>'threadId is required'],422);
if ($body === '') json_response(['success'=>false,'error'=>'Message body is required'],422);
if (strlen($body) > 5000) json_response(['success'=>false,'error'=>'Message too long'],422);

try {
  // Ensure thread exists and participant
  $stmt = $pdo->prepare("SELECT * FROM message_threads WHERE id=:id LIMIT 1");
  $stmt->execute([':id'=>$threadId]);
  $t = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$t) json_response(['success'=>false,'error'=>'Thread not found'],404);

  $patientId = (int)$t['patient_user_id'];
  $viewerId = (int)$t['viewer_user_id'];
  $meId = (int)$me['id'];

  if ($meId !== $patientId && $meId !== $viewerId) {
    json_response(['success'=>false,'error'=>'Forbidden'],403);
  }

  // If staff, ensure access grant is still active
  if ($meId === $viewerId) {
    $stmt = $pdo->prepare("SELECT status FROM access_grants WHERE patient_user_id=:p AND viewer_user_id=:v LIMIT 1");
    $stmt->execute([':p'=>$patientId, ':v'=>$viewerId]);
    $st = strtolower((string)($stmt->fetchColumn() ?: ''));
    if ($st !== 'active') json_response(['success'=>false,'error'=>'Access revoked'],403);
  }

  $pdo->beginTransaction();

  $stmt = $pdo->prepare("INSERT INTO messages (thread_id, sender_user_id, body, created_at) VALUES (:t,:s,:b,NOW())");
  $stmt->execute([':t'=>$threadId, ':s'=>$meId, ':b'=>$body]);
  $msgId = (int)$pdo->lastInsertId();

  // Update thread preview + last message time
  $preview = mb_substr($body, 0, 120);
  $pdo->prepare("UPDATE message_threads SET last_message_at=NOW(), last_message_preview=:p WHERE id=:id")
      ->execute([':p'=>$preview, ':id'=>$threadId]);

  // Mark sender read
  if ($meId === $patientId) {
    $pdo->prepare("UPDATE message_threads SET patient_last_read_at=NOW() WHERE id=:id")
        ->execute([':id'=>$threadId]);
  } else {
    $pdo->prepare("UPDATE message_threads SET viewer_last_read_at=NOW() WHERE id=:id")
        ->execute([':id'=>$threadId]);
  }

  // Notify other user
  $otherId = ($meId === $patientId) ? $viewerId : $patientId;
  notify_user(
    $pdo,
    $otherId,
    $meId,
    'message',
    'New message',
    ((string)$me['fullName']) . ': ' . $preview,
    '/inbox/' . $threadId,
    ['threadId'=>$threadId, 'messageId'=>$msgId]
  );

  $pdo->commit();

  json_response(['success'=>true, 'messageId'=>$msgId, 'threadId'=>$threadId]);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  json_response(['success'=>false,'error'=>'Server error'],500);
}
