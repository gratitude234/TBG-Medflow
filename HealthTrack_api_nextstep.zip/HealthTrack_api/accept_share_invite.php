<?php
// public_html/HealthTrack_api/accept_share_invite.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
$myRole = strtolower((string)$me['role']);

if ($myRole === 'patient') {
    json_response(['success' => false, 'error' => 'Patients cannot accept share codes'], 403);
}

$input = get_json_input();
$code = strtoupper(trim((string)($input['code'] ?? '')));

if ($code === '') {
    json_response(['success' => false, 'error' => 'Share code is required'], 422);
}

try {
    $pdo->beginTransaction();

    // Lock the invite row so two people can't redeem it at once
    $stmt = $pdo->prepare("
      SELECT *
      FROM share_invites
      WHERE code = :c
      LIMIT 1
      FOR UPDATE
    ");
    $stmt->execute([':c' => $code]);
    $invite = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$invite) {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'Invalid share code'], 404);
    }

    if ((string)$invite['status'] !== 'active') {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'This share code is not active'], 409);
    }

    if (!empty($invite['expires_at']) && strtotime((string)$invite['expires_at']) < time()) {
        // Mark expired
        $pdo->prepare("UPDATE share_invites SET status='expired' WHERE id=:id")
            ->execute([':id' => (int)$invite['id']]);
        $pdo->commit();
        json_response(['success' => false, 'error' => 'This share code has expired'], 410);
    }

    $patientId = (int)$invite['patient_user_id'];
    if ($patientId <= 0 || $patientId === (int)$me['id']) {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'Invalid patient link'], 422);
    }

    $allowed = (string)$invite['allowed_role'];
    if ($allowed !== 'any' && $allowed !== $myRole) {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'This code is not allowed for your role'], 403);
    }

    // Create or reactivate grant
    $stmt = $pdo->prepare("
      INSERT INTO access_grants (patient_user_id, viewer_user_id, viewer_role, status, created_at)
      VALUES (:p, :v, :vr, 'active', NOW())
      ON DUPLICATE KEY UPDATE
        viewer_role = VALUES(viewer_role),
        status = 'active',
        revoked_at = NULL
    ");
    $stmt->execute([
        ':p'  => $patientId,
        ':v'  => (int)$me['id'],
        ':vr' => $myRole,
    ]);

    // Mark invite used (one-time code)
    $pdo->prepare("
      UPDATE share_invites
      SET status='used', used_by_user_id=:u, used_at=NOW()
      WHERE id=:id
    ")->execute([
        ':u'  => (int)$me['id'],
        ':id' => (int)$invite['id'],
    ]);

    $pdo->commit();

    json_response([
        'success' => true,
        'message' => 'Access granted',
        'patientUserId' => $patientId,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
