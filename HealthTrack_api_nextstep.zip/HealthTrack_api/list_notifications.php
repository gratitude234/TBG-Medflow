<?php
// public_html/HealthTrack_api/list_notifications.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);

// Staff must be verified to use inbox/notifications
require_verified_staff($me);

$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 30;
if ($limit < 1) $limit = 30;
if ($limit > 100) $limit = 100;

$unreadOnly = (isset($_GET['unread']) && (string)$_GET['unread'] === '1');

try {
  $sql = "
    SELECT id, actor_user_id, type, title, body, link, data_json, read_at, created_at
    FROM notifications
    WHERE user_id = :u
  ";
  if ($unreadOnly) $sql .= " AND read_at IS NULL ";
  $sql .= " ORDER BY created_at DESC LIMIT :lim ";

  $stmt = $pdo->prepare($sql);
  $stmt->bindValue(':u', (int)$me['id'], PDO::PARAM_INT);
  $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // decode JSON if possible
  foreach ($rows as &$r) {
    $dj = $r['data_json'] ?? null;
    if (is_string($dj) && $dj !== '') {
      $decoded = json_decode($dj, true);
      $r['data'] = is_array($decoded) ? $decoded : null;
    } else {
      $r['data'] = null;
    }
    unset($r['data_json']);
  }

  json_response(['success'=>true,'notifications'=>$rows]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
