<?php
// public_html/HealthTrack_api/revoke_care_member.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
require_role($me, ['patient']);

$raw = json_decode((string)file_get_contents('php://input'), true);
$viewerId = (int)($raw['viewerUserId'] ?? 0);

if ($viewerId <= 0) {
  json_response(['success'=>false,'error'=>'Invalid viewer user'],400);
}

try {
  $stmt = $pdo->prepare("
    UPDATE access_grants
    SET status='revoked', revoked_at=NOW()
    WHERE patient_user_id=:p AND viewer_user_id=:v AND status='active'
  ");
  $stmt->execute([
    ':p' => (int)$me['id'],
    ':v' => $viewerId,
  ]);

  // best-effort notify staff
  notify_user(
    $pdo,
    $viewerId,
    (int)$me['id'],
    'access_revoked',
    'Patient revoked access',
    'A patient revoked your access to their records.',
    '/dashboard',
    ['patientUserId' => (int)$me['id']]
  );

  json_response(['success'=>true,'revoked'=>($stmt->rowCount() > 0)]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
