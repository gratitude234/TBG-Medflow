<?php
// public_html/HealthTrack_api/get_messages.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
$role = normalize_role((string)($me['role'] ?? 'patient'));
if ($role !== 'patient') require_verified_staff($me);

$threadId = (int)($_GET['threadId'] ?? 0);
$limit = (int)($_GET['limit'] ?? 80);
if ($limit < 1) $limit = 80;
if ($limit > 200) $limit = 200;

if ($threadId <= 0) {
  json_response(['success'=>false,'error'=>'threadId is required'],422);
}

try {
  $stmt = $pdo->prepare("SELECT * FROM message_threads WHERE id=:id LIMIT 1");
  $stmt->execute([':id' => $threadId]);
  $t = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$t) json_response(['success'=>false,'error'=>'Thread not found'],404);

  $isParticipant = ((int)$t['patient_user_id'] === (int)$me['id']) || ((int)$t['viewer_user_id'] === (int)$me['id']);
  if (!$isParticipant) json_response(['success'=>false,'error'=>'Forbidden'],403);

  // If staff, ensure still has active grant
  if ($role !== 'patient') {
    $stmt = $pdo->prepare("SELECT 1 FROM access_grants WHERE patient_user_id=:p AND viewer_user_id=:v AND status='active' LIMIT 1");
    $stmt->execute([':p' => (int)$t['patient_user_id'], ':v' => (int)$me['id']]);
    if (!$stmt->fetchColumn()) json_response(['success'=>false,'error'=>'Access revoked'],403);
  }

  $stmt = $pdo->prepare("
    SELECT m.id, m.sender_user_id AS senderUserId, m.body, m.created_at AS createdAt
    FROM messages m
    WHERE m.thread_id = :tid
    ORDER BY m.id DESC
    LIMIT :lim
  ");
  $stmt->bindValue(':tid', $threadId, PDO::PARAM_INT);
  $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Return oldest-first
  $rows = array_reverse($rows);

  json_response(['success'=>true,'thread'=>$t,'messages'=>$rows]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
