<?php
// public_html/HealthTrack_api/create_share_invite.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);
if (strtolower((string)$me['role']) !== 'patient') {
    json_response(['success' => false, 'error' => 'Only patients can create share codes'], 403);
}

$input = get_json_input();

$allowedRole = strtolower(trim((string)($input['allowedRole'] ?? 'any')));
$allowedRoles = ['any', 'student', 'clinician', 'other'];
if (!in_array($allowedRole, $allowedRoles, true)) $allowedRole = 'any';

// Default expiry: 72 hours (3 days)
$expiresInHours = (int)($input['expiresInHours'] ?? 72);
if ($expiresInHours < 1) $expiresInHours = 72;
if ($expiresInHours > 24 * 30) $expiresInHours = 24 * 30; // cap at 30 days

try {
    $pdo->beginTransaction();

    // Generate unique code (retry a few times)
    $code = '';
    for ($i = 0; $i < 6; $i++) {
        $code = strtoupper(bin2hex(random_bytes(4))); // 8 bytes => 16 hex chars
        try {
            $stmt = $pdo->prepare("
              INSERT INTO share_invites (patient_user_id, code, allowed_role, status, expires_at, created_at)
              VALUES (:p, :c, :ar, 'active', DATE_ADD(NOW(), INTERVAL :hrs HOUR), NOW())
            ");
            $stmt->execute([
                ':p'   => (int)$me['id'],
                ':c'   => $code,
                ':ar'  => $allowedRole,
                ':hrs' => $expiresInHours,
            ]);
            break;
        } catch (Throwable $e) {
            // likely duplicate code, retry
            $code = '';
        }
    }

    if ($code === '') {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'Could not generate a unique code'], 500);
    }

    $pdo->commit();

    json_response([
        'success'   => true,
        'code'      => $code,
        'expiresAt' => date('c', time() + ($expiresInHours * 3600)),
        'allowedRole' => $allowedRole,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
