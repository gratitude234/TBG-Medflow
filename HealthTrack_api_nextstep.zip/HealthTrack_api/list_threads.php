<?php
// public_html/HealthTrack_api/list_threads.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);
$role = normalize_role((string)($me['role'] ?? 'patient'));
if ($role !== 'patient') {
  require_verified_staff($me);
}

$limit = (int)($_GET['limit'] ?? 30);
if ($limit < 1) $limit = 30;
if ($limit > 100) $limit = 100;

try {
  if ($role === 'patient') {
    $sql = "
      SELECT
        t.id,
        t.patient_user_id,
        t.viewer_user_id,
        t.last_message_at,
        t.last_message_preview,
        t.patient_last_read_at,
        t.viewer_last_read_at,
        u.full_name AS otherFullName,
        u.email AS otherEmail,
        u.role AS otherRole,
        (
          SELECT COUNT(*)
          FROM messages m
          WHERE m.thread_id = t.id
            AND m.sender_user_id <> :me
            AND (t.patient_last_read_at IS NULL OR m.created_at > t.patient_last_read_at)
        ) AS unreadCount
      FROM message_threads t
      JOIN users u ON u.id = t.viewer_user_id
      WHERE t.patient_user_id = :me
      ORDER BY COALESCE(t.last_message_at, t.created_at) DESC
      LIMIT :lim
    ";
  } else {
    $sql = "
      SELECT
        t.id,
        t.patient_user_id,
        t.viewer_user_id,
        t.last_message_at,
        t.last_message_preview,
        t.patient_last_read_at,
        t.viewer_last_read_at,
        u.full_name AS otherFullName,
        u.email AS otherEmail,
        u.role AS otherRole,
        (
          SELECT COUNT(*)
          FROM messages m
          WHERE m.thread_id = t.id
            AND m.sender_user_id <> :me
            AND (t.viewer_last_read_at IS NULL OR m.created_at > t.viewer_last_read_at)
        ) AS unreadCount
      FROM message_threads t
      JOIN users u ON u.id = t.patient_user_id
      WHERE t.viewer_user_id = :me
      ORDER BY COALESCE(t.last_message_at, t.created_at) DESC
      LIMIT :lim
    ";
  }

  $stmt = $pdo->prepare($sql);
  $stmt->bindValue(':me', (int)$me['id'], PDO::PARAM_INT);
  $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  json_response(['success'=>true,'threads'=>$rows]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
