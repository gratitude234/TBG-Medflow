<?php
// public_html/HealthTrack_api/helpers.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';

if (!function_exists('normalize_role')) {
    function normalize_role(string $role): string {
        $r = strtolower(trim($role));
        return in_array($r, ['patient','student','clinician','other'], true) ? $r : 'patient';
    }
}

if (!function_exists('require_verified_staff')) {
    /**
     * Blocks access for staff accounts unless verificationStatus === 'verified'.
     * Patients are allowed regardless.
     */
    function require_verified_staff(array $me): void {
        $role = normalize_role((string)($me['role'] ?? 'patient'));
        if ($role === 'patient') return;

        $vs = strtolower((string)($me['verificationStatus'] ?? 'unverified'));
        if ($vs !== 'verified') {
            json_response([
                'success' => false,
                'error' => 'Account not verified yet. Please request verification and wait for approval.',
                'verificationStatus' => $vs,
            ], 403);
        }
    }
}

if (!function_exists('require_role')) {
    function require_role(array $me, array $allowedRoles): void {
        $role = normalize_role((string)($me['role'] ?? 'patient'));
        $allowed = array_map('normalize_role', $allowedRoles);
        if (!in_array($role, $allowed, true)) {
            json_response(['success' => false, 'error' => 'Forbidden'], 403);
        }
    }
}

if (!function_exists('notify_user')) {
    /**
     * Insert a notification row (best-effort). Safe even if notifications table isn't present.
     */
    function notify_user(PDO $pdo, int $userId, ?int $actorUserId, string $type, string $title, ?string $body = null, ?string $link = null, $data = null): void {
        try {
            $dataJson = null;
            if ($data !== null) {
                $dataJson = json_encode($data, JSON_UNESCAPED_SLASHES);
            }
            $stmt = $pdo->prepare(
                "INSERT INTO notifications (user_id, actor_user_id, type, title, body, link, data_json, created_at)
                 VALUES (:u, :a, :t, :ti, :b, :l, :d, NOW())"
            );
            $stmt->execute([
                ':u' => $userId,
                ':a' => $actorUserId,
                ':t' => $type,
                ':ti' => $title,
                ':b' => $body,
                ':l' => $link,
                ':d' => $dataJson,
            ]);
        } catch (Throwable $e) {
            // ignore
        }
    }
}

