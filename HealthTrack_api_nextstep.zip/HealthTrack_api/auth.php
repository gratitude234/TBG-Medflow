<?php
// public_html/HealthTrack_api/auth.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';

/**
 * Checks if a column exists in the `users` table.
 * Uses DATABASE() so it works without hardcoding schema name.
 */
function users_column_exists(PDO $pdo, string $column): bool {
    $stmt = $pdo->prepare("
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'users'
          AND COLUMN_NAME = :col
        LIMIT 1
    ");
    $stmt->execute([':col' => $column]);
    return (bool)$stmt->fetchColumn();
}

function get_bearer_token(): string {
    $auth = '';

    // Most common
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = (string)$_SERVER['HTTP_AUTHORIZATION'];
    } elseif (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (!empty($headers['Authorization'])) $auth = (string)$headers['Authorization'];
        elseif (!empty($headers['authorization'])) $auth = (string)$headers['authorization'];
    }

    $auth = trim($auth);
    if ($auth === '') return '';

    if (stripos($auth, 'Bearer ') === 0) {
        return trim(substr($auth, 7));
    }
    return '';
}

/**
 * Returns authenticated user (array) or ends request with 401.
 * Requires `user_tokens` table with token_hash (sha256).
 */
function require_auth(PDO $pdo): array {
    $token = get_bearer_token();
    if ($token === '') {
        json_response(['success' => false, 'error' => 'Missing Authorization token'], 401);
    }

    $hash = hash('sha256', $token);

    $hasOnboarding = users_column_exists($pdo, 'onboarding_complete');
    $hasVerification = users_column_exists($pdo, 'verification_status');

    $select = "
      u.id,
      u.full_name,
      u.email,
      u.role,
      " . ($hasOnboarding ? "u.onboarding_complete," : "0 AS onboarding_complete,") . "
      " . ($hasVerification ? "u.verification_status," : "'unverified' AS verification_status,") . "
      u.created_at,
      ut.id AS token_id
    ";

    $sql = "
      SELECT $select
      FROM user_tokens ut
      JOIN users u ON u.id = ut.user_id
      WHERE ut.token_hash = :h
        AND ut.revoked = 0
        AND (ut.expires_at IS NULL OR ut.expires_at > NOW())
      LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':h' => $hash]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        json_response(['success' => false, 'error' => 'Invalid or expired token'], 401);
    }

    // Update last_used_at (best-effort)
    try {
        $pdo->prepare("UPDATE user_tokens SET last_used_at = NOW() WHERE id = :id")
            ->execute([':id' => (int)$row['token_id']]);
    } catch (Throwable $e) {
        // ignore
    }

    return [
        'id'                 => (int)$row['id'],
        'fullName'           => (string)$row['full_name'],
        'email'              => (string)$row['email'],
        'role'               => (string)$row['role'],
        'onboardingComplete' => ((int)$row['onboarding_complete'] === 1),
        'verificationStatus' => (string)($row['verification_status'] ?? 'unverified'),
        'createdAt'          => (string)$row['created_at'],
    ];
}
