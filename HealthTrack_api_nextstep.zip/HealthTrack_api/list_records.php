<?php
// public_html/HealthTrack_api/list_records.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/access.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if (!in_array($method, ['GET', 'POST'], true)) {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$me = require_auth($pdo);

$input = [];
if ($method === 'POST') {
    $input = get_json_input();
}

// Backward compatible: accept patientUserId OR userId/user_id
$patientUserId =
    (int)($input['patientUserId'] ?? 0) ? (int)$input['patientUserId'] :
    ((int)($_GET['patientUserId'] ?? 0) ? (int)$_GET['patientUserId'] :
    ((int)($input['userId'] ?? 0) ? (int)$input['userId'] :
    ((int)($input['user_id'] ?? 0) ? (int)$input['user_id'] :
    ((int)($_GET['userId'] ?? 0) ? (int)$_GET['userId'] :
    (int)($_GET['user_id'] ?? 0)))));

// Default: if not provided, list own records
if ($patientUserId <= 0) {
    $patientUserId = (int)$me['id'];
}

// Permission check
require_patient_access($pdo, $me, $patientUserId);

// Optional limit (POST or GET). Good for "last record" fetch.
$limit = 0;
if (isset($input['limit'])) $limit = (int)$input['limit'];
if (isset($_GET['limit'])) $limit = (int)$_GET['limit'];

if ($limit < 0) $limit = 0;
if ($limit > 200) $limit = 200; // safety cap

try {
    $sql = "
        SELECT
            id,
            user_id AS patient_user_id,
            entered_by_user_id,
            entered_by_role,
            record_date,
            record_time,
            session,
            bp_systolic,
            bp_diastolic,
            heart_rate,
            temperature,
            blood_sugar,
            symptoms,
            notes,
            taken_medication,
            fasting,
            share_with_clinician,
            created_at
        FROM health_records
        WHERE user_id = :patient_user_id
        ORDER BY record_date DESC, record_time DESC, created_at DESC
    ";

    if ($limit > 0) {
        $sql .= " LIMIT :limit";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':patient_user_id', $patientUserId, PDO::PARAM_INT);
    if ($limit > 0) {
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    }

    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    json_response([
        'success' => true,
        'patientUserId' => $patientUserId,
        'records' => $rows,
    ]);
} catch (Throwable $e) {
    $debug = true; // switch to false in production
    json_response([
        'success' => false,
        'error'   => $debug ? $e->getMessage() : 'Server error',
    ], 500);
}
