<?php
// public_html/HealthTrack_api/mark_notifications_read.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/helpers.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  json_response(['success'=>false,'error'=>'Method not allowed'],405);
}

$me = require_auth($pdo);

$input = get_json_input();
$markAll = (bool)($input['markAll'] ?? false);
$ids = $input['ids'] ?? [];
if (!is_array($ids)) $ids = [];

try {
  if ($markAll) {
    $stmt = $pdo->prepare("UPDATE notifications SET read_at=NOW() WHERE user_id=:u AND read_at IS NULL");
    $stmt->execute([':u' => (int)$me['id']]);
    json_response(['success'=>true,'updated' => $stmt->rowCount()]);
  }

  $clean = [];
  foreach ($ids as $id) {
    $id = (int)$id;
    if ($id > 0) $clean[] = $id;
  }

  if (count($clean) === 0) {
    json_response(['success'=>false,'error'=>'No ids provided'],422);
  }

  $placeholders = implode(',', array_fill(0, count($clean), '?'));
  $sql = "UPDATE notifications SET read_at=NOW() WHERE user_id=? AND id IN ($placeholders)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array_merge([(int)$me['id']], $clean));

  json_response(['success'=>true,'updated' => $stmt->rowCount()]);
} catch (Throwable $e) {
  json_response(['success'=>false,'error'=>'Server error'],500);
}
