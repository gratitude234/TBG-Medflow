<?php
// public_html/HealthTrack_api/review_verification_request.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'error' => 'Method not allowed'], 405);
}

$admin = require_auth($pdo);

// Admin check (MVP): role OR allowlisted email
$role = strtolower((string)($admin['role'] ?? ''));
$allowedRoles = ['admin', 'super_admin'];
$allowed = in_array($role, $allowedRoles, true);
if (!$allowed) {
    global $ADMIN_EMAILS;
    $allowed = is_array($ADMIN_EMAILS) && in_array(strtolower((string)($admin['email'] ?? '')), array_map('strtolower', $ADMIN_EMAILS), true);
}

if (!$allowed) {
    json_response(['success' => false, 'error' => 'Forbidden'], 403);
}

$input = get_json_input();

$requestId = (int)($input['requestId'] ?? $input['request_id'] ?? 0);
$action = strtolower(trim((string)($input['action'] ?? '')));
$reviewNote = trim((string)($input['reviewNote'] ?? $input['review_note'] ?? ''));

if ($requestId <= 0) {
    json_response(['success' => false, 'error' => 'requestId is required'], 422);
}
if (!in_array($action, ['approve', 'reject'], true)) {
    json_response(['success' => false, 'error' => "action must be 'approve' or 'reject'"], 422);
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT vr.*, u.full_name, u.email, u.role AS user_role
                           FROM verification_requests vr
                           JOIN users u ON u.id = vr.user_id
                           WHERE vr.id = :id
                           LIMIT 1");
    $stmt->execute([':id' => $requestId]);
    $req = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$req) {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'Request not found'], 404);
    }

    if ((string)$req['status'] !== 'pending') {
        $pdo->rollBack();
        json_response(['success' => false, 'error' => 'This request is already reviewed.'], 409);
    }

    $newStatus = $action === 'approve' ? 'approved' : 'rejected';

    $stmt = $pdo->prepare("UPDATE verification_requests
                           SET status = :st,
                               updated_at = NOW(),
                               reviewed_by_user_id = :rid,
                               reviewed_at = NOW(),
                               review_note = :rn
                           WHERE id = :id");
    $stmt->execute([
        ':st' => $newStatus,
        ':rid' => (int)$admin['id'],
        ':rn' => ($reviewNote !== '' ? $reviewNote : null),
        ':id' => $requestId,
    ]);

    // Update users table if verification_status exists
    if (users_column_exists($pdo, 'verification_status')) {
        if ($action === 'approve') {
            $stmt = $pdo->prepare("UPDATE users
                                   SET verification_status = 'verified',
                                       verified_at = NOW(),
                                       verified_by_user_id = :aid,
                                       verification_note = :rn
                                   WHERE id = :uid");
            $stmt->execute([
                ':aid' => (int)$admin['id'],
                ':rn' => ($reviewNote !== '' ? $reviewNote : null),
                ':uid' => (int)$req['user_id'],
            ]);
        } else {
            $stmt = $pdo->prepare("UPDATE users
                                   SET verification_status = 'rejected',
                                       verified_at = NULL,
                                       verified_by_user_id = NULL,
                                       verification_note = :rn
                                   WHERE id = :uid");
            $stmt->execute([
                ':rn' => ($reviewNote !== '' ? $reviewNote : 'Rejected'),
                ':uid' => (int)$req['user_id'],
            ]);
        }
    }

    $pdo->commit();

    // Notify requester (best-effort)
    try {
        $title = $action === 'approve' ? 'Verification approved' : 'Verification rejected';
        $body = $action === 'approve'
            ? 'Your staff verification has been approved. You can now receive shares and reply to patients.'
            : ('Your verification request was rejected.' . ($reviewNote !== '' ? (' Note: ' . $reviewNote) : ''));

        $pdo->prepare("INSERT INTO notifications (user_id, actor_user_id, type, title, body, link, created_at)
                       VALUES (:uid, :actor, 'verification_result', :t, :b, '/profile', NOW())")
            ->execute([
                ':uid' => (int)$req['user_id'],
                ':actor' => (int)$admin['id'],
                ':t' => $title,
                ':b' => $body,
            ]);
    } catch (Throwable $e) {
        // ignore
    }

    json_response([
        'success' => true,
        'status' => $newStatus,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[review_verification_request] ' . $e->getMessage());
    json_response(['success' => false, 'error' => 'Server error'], 500);
}
