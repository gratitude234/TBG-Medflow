<?php
// public_html/HealthTrack_api/config.php
declare(strict_types=1);

require_once __DIR__ . '/response.php';

// --------------------------------------------------
// Debug (DEV only; turn off in production)
// --------------------------------------------------
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// --------------------------------------------------
// Database connection
// --------------------------------------------------
$db_host = 'localhost';
$db_name = 'hrfjgoot_HealthTrack';
$db_user = 'hrfjgoot_Gratitude';
$db_pass = '@kP2G7AhxTt4t4M';

$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // ✅ critical
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,                  // ✅ better type safety
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (Throwable $e) {
    // ✅ log the real connection error
    error_log("[config] DB connection failed: " . $e->getMessage());
    json_response([
        'success' => false,
        'error'   => 'Database connection failed',
    ], 500);
}

// --------------------------------------------------
// Admin allowlist (MVP)
// --------------------------------------------------
// You can set this on your hosting as: MEDFLOW_ADMIN_EMAILS="a@b.com,c@d.com"
// If unset, we default to the project owner's email.
$ADMIN_EMAILS = array_values(array_filter(array_map('trim', explode(',', (string)(getenv('MEDFLOW_ADMIN_EMAILS') ?: 'gratitudeolanibi2020@gmail.com'))))));

